const Fa = (() => {
    const FA = '۰۱۲۳۴۵۶۷۸۹';
    const AR = '٠١٢٣٤٥٦٧٨٩';
    function toFa(v) {
        return String(v == null ? '' : v).replace(/[0-9]/g, d => FA[Number(d)]);
    }
    function toEn(v) {
        return String(v == null ? '' : v)
            .replace(/[۰-۹]/g, d => String(FA.indexOf(d)))
            .replace(/[٠-٩]/g, d => String(AR.indexOf(d)))
            .replace(/٫/g, '.')
            .replace(/٬/g, '');
    }
    function digitsOnly(v) {
        return toEn(v).replace(/[^0-9]/g, '');
    }
    function parseAnswer(v) {
        const s = digitsOnly(v);
        return s === '' ? NaN : Number(s);
    }
    function parseSigned(v) {
        const raw = toEn(v).trim();
        const neg = /^[-−–‒]/.test(raw);
        const s = digitsOnly(raw);
        return s === '' ? NaN : (neg ? -Number(s) : Number(s));
    }
    function num(n, decimals = 0) {
        if (n == null || Number.isNaN(Number(n)))
            return '—';
        const s = decimals ? Number(n).toFixed(decimals) : String(Math.round(Number(n)));
        const neg = s.startsWith('-');
        const out = toFa(neg ? s.slice(1) : s).replace('.', '٫');
        return neg ? '\u2066−' + out + '\u2069' : out;
    }
    function group(n) {
        if (n == null || Number.isNaN(Number(n)))
            return '—';
        return toFa(Math.round(Number(n)).toLocaleString('en-US')).replace(/,/g, '٬');
    }
    function bindDigitInput(input) {
        if (!input)
            return;
        input.addEventListener('input', () => {
            const raw = toEn(input.value);
            const v = (/^\s*[-−–‒]/.test(raw) ? '-' : '') + toFa(digitsOnly(raw));
            if (v !== input.value)
                input.value = v;
        });
    }
    function jalaliPart(date, opts) {
        try {
            return new Intl.DateTimeFormat('fa-IR-u-ca-persian', opts).format(date);
        }
        catch (e) {
            return null;
        }
    }
    function jalaliDayFromKey(key) {
        const [y, m, d] = key.split('-').map(Number);
        const dt = new Date(y, m - 1, d);
        return jalaliPart(dt, { day: 'numeric' }) || toFa(d);
    }
    function jalaliDate(ts) {
        const dt = new Date(ts);
        return jalaliPart(dt, { year: 'numeric', month: 'long', day: 'numeric' })
            || toFa(dt.toLocaleDateString('en-GB'));
    }
    function timeOfDay(ts) {
        const dt = new Date(ts);
        return toFa(String(dt.getHours()).padStart(2, '0') + ':' + String(dt.getMinutes()).padStart(2, '0'));
    }
    const SKIP_TAGS = new Set(['SCRIPT', 'STYLE', 'TEXTAREA', 'INPUT', 'CODE']);
    const HAS_LATIN_DIGIT = /[0-9]/;
    function shouldSkip(el) {
        for (let p = el; p && p.nodeType === 1; p = p.parentNode) {
            if (SKIP_TAGS.has(p.tagName))
                return true;
            if (p.hasAttribute && p.hasAttribute('data-latin'))
                return true;
        }
        return false;
    }
    function localizeNode(node) {
        if (!node)
            return;
        if (node.nodeType === 3) {
            if (HAS_LATIN_DIGIT.test(node.nodeValue) && !shouldSkip(node.parentNode)) {
                node.nodeValue = toFa(node.nodeValue);
            }
            return;
        }
        if (node.nodeType !== 1 || shouldSkip(node))
            return;
        const walker = document.createTreeWalker(node, NodeFilter.SHOW_TEXT);
        const hits = [];
        let n;
        while ((n = walker.nextNode())) {
            if (HAS_LATIN_DIGIT.test(n.nodeValue) && !shouldSkip(n.parentNode))
                hits.push(n);
        }
        hits.forEach(t => { t.nodeValue = toFa(t.nodeValue); });
    }
    let observer = null;
    function watch(root = document.body) {
        localizeNode(root);
        if (observer || typeof MutationObserver === 'undefined')
            return;
        observer = new MutationObserver(muts => {
            for (const m of muts) {
                if (m.type === 'characterData')
                    localizeNode(m.target);
                else
                    m.addedNodes.forEach(localizeNode);
            }
        });
        observer.observe(root, { childList: true, subtree: true, characterData: true });
    }
    return {
        toFa, toEn, digitsOnly, parseAnswer, parseSigned, num, group,
        bindDigitInput, localizeNode, watch,
        jalaliDayFromKey, jalaliDate, timeOfDay,
    };
})();
window.Fa = Fa;
