const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
function toast(msg) {
    const wrap = $('[data-el="toastWrap"]');
    const el = document.createElement('div');
    el.className = 'toast';
    el.textContent = msg;
    wrap.appendChild(el);
    setTimeout(() => el.remove(), 2600);
}
const Router = (() => {
    const views = { home: $('#view-home'), practice: $('#view-practice'), result: $('#view-result'), progress: $('#view-progress'), settings: $('#view-settings'), shop: $('#view-shop') };
    let current = 'home';
    function navigate(route) {
        if (!views[route])
            return;
        if (Themes.previewing())
            Themes.endPreview();
        views[current].classList.remove('active');
        views[route].classList.add('active');
        current = route;
        document.body.classList.toggle('in-test', route === 'practice');
        if (route !== 'practice')
            Pad.close();
        $$('[data-nav] button, [data-nav-mobile] button').forEach(b => b.classList.toggle('active', b.dataset.route === route));
        if (route === 'home')
            renderHome();
        if (route === 'progress')
            renderProgress();
        if (route === 'shop' && window.Shop)
            Shop.render();
        window.scrollTo({ top: 0, behavior: 'instant' in window ? 'instant' : 'auto' });
    }
    return { navigate, get current() { return current; } };
})();
function updateHud() {
    const info = Progression.levelInfo(Storage.data.profile.totalXP);
    $$('[data-hud="level"]').forEach(el => el.textContent = info.level);
    $$('[data-hud="xp"]').forEach(el => el.textContent = Storage.data.profile.totalXP);
    $$('[data-hud="coins"]').forEach(el => el.textContent = Storage.data.profile.coins);
}
function renderHome() {
    Mascot.mount();
    const agg = Stats.overallAggregate();
    $('[data-home="streakDays"]').textContent = agg.currentDayStreak;
    $('[data-home="totalQuestions"]').textContent = agg.totalQuestions;
    $('[data-home="accuracy"]').textContent = agg.totalQuestions ? Stats.fmtPct(agg.overallAccuracy) : '—';
    const list = $('[data-coach-list]');
    list.innerHTML = '';
    Coach.homeInsights().forEach(line => {
        const li = document.createElement('li');
        li.textContent = line.text;
        if (line.kind === 'fact')
            li.className = 'coach-fact';
        list.appendChild(li);
    });
    const dc = Progression.getTodayChallenge();
    const desc = $('[data-daily-desc]');
    if (dc.completed) {
        desc.textContent = `تکمیل شد ✅ — ${dc.result.correct}/${dc.result.total} درست`;
    }
    else {
        desc.textContent = `${dc.target.questionCount} سؤال — هدف: کمتر از ${Math.round(dc.target.timeGoalMs / 1000)} ثانیه`;
    }
}
const MODE_META = {
    adaptive: { label: 'تمرین هدفمند', kind: 'count', count: 20 },
    equation: { label: 'معادله', kind: 'count', count: 12, adv: 'eq', sub: true, signed: true },
    integers: { label: 'جمع‌های صحیح', kind: 'count', count: 15, adv: 'int', sub: true, signed: true },
    primes: { label: 'اول یا مرکب', kind: 'count', count: 15, adv: 'prime', sub: true, choice: true, prime: true },
    choice4: { label: 'ضرب چهارگزینه‌ای', kind: 'count', count: 20, choice: true },
    speed30: { label: 'تمرین سرعتی (۳۰ ثانیه)', kind: 'timed', seconds: 30 },
    speed60: { label: 'تمرین سرعتی (۶۰ ثانیه)', kind: 'timed', seconds: 60 },
    endurance: { label: 'آزمون ۳ دقیقه‌ای', kind: 'timed', seconds: 180 },
    fixed20: { label: 'آزمون ۲۰ سؤالی', kind: 'count', count: () => Storage.data.settings.questionCount },
    mental: { label: 'تمرین ذهنی', kind: 'count', count: 15, mental: true },
    accuracy: { label: 'آزمون دقت', kind: 'count', count: 20 },
    daily: { label: 'چالش امروز', kind: 'count', count: () => Progression.getTodayChallenge().target.questionCount, daily: true },
    placement: { label: 'تعیین سطح', kind: 'count', count: 8, placement: true },
};
const PLACEMENT_SEQUENCE = ['1x1', '1x1', '1x1', '2x1', '2x1', '2x2', '2x2', '3x1'];
const Practice = (() => {
    const el = {
        countdown: $('[data-stage="countdown"]'),
        countdownNum: $('[data-el="countdownNum"]'),
        questionStage: $('[data-stage="question"]'),
        questionText: $('[data-el="questionText"]'),
        answerInput: $('[data-el="answerInput"]'),
        mentalShow: $('[data-stage="mentalShow"]'),
        choiceStage: $('[data-stage="choices"]'),
        choiceQuestion: $('[data-el="choiceQuestion"]'),
        choiceGrid: $('[data-el="choiceGrid"]'),
        mentalQuestionText: $('[data-el="mentalQuestionText"]'),
        mentalAnswer: $('[data-stage="mentalAnswer"]'),
        mentalAnswerInput: $('[data-el="mentalAnswerInput"]'),
        flash: $('[data-el="flash"]'),
        combo: $('[data-el="combo"]'),
        tapArea: $('[data-el="tapArea"]'),
        stage: $('.practice-stage'),
        timerBarWrap: $('[data-el="timerBarWrap"]'),
        timerBar: $('[data-el="timerBar"]'),
        hudQIndex: $('[data-p="qIndex"]'),
        hudQTotal: $('[data-p="qTotal"]'),
        hudQTotalWrap: $('[data-p="qTotalWrap"]'),
        hudCorrect: $('[data-p="correct"]'),
        hudWrong: $('[data-p="wrong"]'),
        hudTimeLeft: $('[data-p="timeLeft"]'),
        hudTimeWrap: $('[data-p="timeWrap"]'),
    };
    let session = null;
    let intervalHandle = null;
    let advanceTimeout = null;
    let countdownTimer = null;
    let lastRun = null;
    function stages(active) {
        [el.countdown, el.questionStage, el.mentalShow, el.mentalAnswer, el.choiceStage].forEach(s => s.classList.add('hidden'));
        if (active)
            active.classList.remove('hidden');
    }
    function start(modeKey, plan) {
        {
            const m0 = MODE_META[modeKey];
            if (m0 && m0.sub && !Sub.active()) {
                toast('این حالت مخصوص اشتراک است 🔒');
                Router.navigate('shop');
                return;
            }
        }
        const meta = MODE_META[modeKey];
        if (!meta)
            return;
        const count = typeof meta.count === 'function' ? meta.count() : meta.count;
        if (!plan && (modeKey === 'adaptive' || modeKey === 'choice4'))
            plan = Coach.buildPlan();
        if (modeKey === 'choice4' && plan && plan.type !== Adaptive.currentType())
            plan = Object.assign({}, plan, { type: Adaptive.currentType() });
        const usePlan = !meta.placement && !meta.daily && plan ? plan : null;
        lastRun = !meta.placement && !meta.daily ? { modeKey, plan: usePlan } : null;
        session = {
            plan: usePlan, weakAtStart: usePlan ? usePlan.focusFacts.slice() : [], coins: 0,
            picker: usePlan ? Adaptive.createPicker(usePlan.type, usePlan) : null,
            mode: modeKey, meta, count, index: 0,
            correct: 0, wrong: 0, totalTimeMs: 0, bestTime: null,
            combo: 0, bestCombo: 0, xpEarned: 0,
            answers: [],
            placementResults: {},
            state: 'idle',
            startedAt: Date.now(),
        };
        el.answerInput.classList.remove('correct', 'wrong');
        el.tapArea.classList.add('hidden');
        el.hudQIndex.textContent = 0;
        el.hudCorrect.textContent = 0;
        el.hudWrong.textContent = 0;
        if (meta.kind === 'count') {
            el.hudQTotalWrap.classList.remove('hidden');
            el.hudQTotal.textContent = count;
            el.hudTimeWrap.classList.add('hidden');
            el.timerBarWrap.classList.add('hidden');
        }
        else {
            el.hudQTotalWrap.classList.add('hidden');
            el.hudTimeWrap.classList.remove('hidden');
            el.hudTimeLeft.textContent = meta.seconds;
            el.timerBarWrap.classList.remove('hidden');
            el.timerBar.style.width = '100%';
            el.timerBar.classList.remove('low');
        }
        Router.navigate('practice');
        runCountdown();
    }
    function runCountdown() {
        stages(el.countdown);
        const seq = ['۳', '۲', '۱', 'شروع!'];
        let i = 0;
        el.countdownNum.textContent = seq[0];
        AudioFx.tick();
        const step = () => {
            i++;
            if (i < seq.length) {
                el.countdownNum.textContent = seq[i];
                el.countdownNum.style.animation = 'none';
                void el.countdownNum.offsetWidth;
                el.countdownNum.style.animation = '';
                AudioFx.tick();
                countdownTimer = setTimeout(step, 550);
            }
            else {
                AudioFx.start();
                countdownTimer = setTimeout(beginLoop, 400);
            }
        };
        clearTimeout(countdownTimer);
        countdownTimer = setTimeout(step, 550);
    }
    function beginLoop() {
        if (!session)
            return;
        if (session.meta.kind === 'timed') {
            session.timeLeft = session.meta.seconds;
            intervalHandle = setInterval(tickTimer, 1000);
        }
        loadNext();
    }
    function tickTimer() {
        if (!session) {
            clearInterval(intervalHandle);
            return;
        }
        session.timeLeft--;
        el.hudTimeLeft.textContent = session.timeLeft;
        const pct = Math.max(0, (session.timeLeft / session.meta.seconds) * 100);
        el.timerBar.style.width = pct + '%';
        if (pct < 20)
            el.timerBar.classList.add('low');
        if (session.timeLeft <= 0) {
            clearInterval(intervalHandle);
            finish();
        }
    }
    function currentQuestionType() {
        if (session.meta.placement)
            return PLACEMENT_SEQUENCE[session.index];
        if (session.meta.daily)
            return Progression.getTodayChallenge().target.type;
        if (session.meta.adv)
            return session.meta.adv;
        if (session.plan)
            return session.plan.type;
        return Adaptive.currentType();
    }
    function loadNext() {
        Pad.onQuestion();
        if (session.meta.kind === 'count' && session.index >= session.count)
            return finish();
        session.index++;
        el.hudQIndex.textContent = session.index;
        el.answerInput.value = '';
        el.answerInput.classList.remove('correct', 'wrong');
        const type = currentQuestionType();
        const recentKeys = Storage.data.recentQuestions.slice(-6).map(q => q.key);
        const q = session.meta.adv ? Advanced.next(session.meta.adv) : session.picker ? session.picker() : QuestionGenerator.generate(type, { recentKeys });
        Storage.data.recentQuestions.push({ key: q.key, type: q.type, t: Date.now() });
        session.current = { q, shownAt: performance.now() };
        el.tapArea.classList.add('hidden');
        if (session.meta.mental) {
            session.state = 'mentalWait';
            stages(el.mentalShow);
            el.mentalQuestionText.textContent = q.display;
            el.mentalAnswerInput.value = '';
            el.mentalAnswerInput.classList.remove('correct', 'wrong');
            const dur = Storage.data.settings.mentalDisplayTime;
            advanceTimeout = setTimeout(() => {
                stages(el.mentalAnswer);
                el.mentalAnswerInput.value = '';
                el.mentalAnswerInput.classList.remove('correct', 'wrong');
                el.mentalAnswerInput.focus();
                session.current.answerShownAt = performance.now();
                session.state = 'entering';
            }, dur);
        }
        else if (session.meta.choice) {
            session.state = 'entering';
            stages(el.choiceStage);
            el.choiceQuestion.textContent = q.display;
            const past = Object.keys((Storage.data.factStats[q.key] || {}).wrongAns || {}).map(Number);
            const options = q.prime ? [1, 0] : QuestionGenerator.makeChoices(q, { pastWrong: past }).options;
            el.choiceGrid.classList.toggle('two', !!q.prime);
            el.choiceGrid.innerHTML = '';
            options.forEach(v => {
                const b = document.createElement('button');
                b.type = 'button';
                b.className = 'choice-btn';
                b.dataset.v = v;
                b.textContent = q.prime ? (v ? 'اول' : 'مرکب') : Fa.toFa(v);
                b.addEventListener('click', (e) => { e.stopPropagation(); submit(v); });
                el.choiceGrid.appendChild(b);
            });
        }
        else {
            session.state = 'entering';
            stages(el.questionStage);
            el.questionText.textContent = q.display;
            el.questionText.classList.toggle('adv', !!session.meta.adv);
            $('[data-el="signBtn"]').classList.toggle('hidden', !session.meta.signed);
            el.answerInput.focus();
        }
    }
    function activeInput() {
        return session.meta.mental ? el.mentalAnswerInput : el.answerInput;
    }
    function markChoices(picked, q) {
        $$('.choice-btn', el.choiceGrid).forEach(b => {
            const v = Number(b.dataset.v);
            b.disabled = true;
            if (v === q.answer)
                b.classList.add('correct');
            else if (v === picked)
                b.classList.add('wrong');
            else
                b.classList.add('dim');
        });
        if (q.prime && picked !== q.answer)
            el.choiceQuestion.textContent = q.explain;
    }
    function submit(choiceVal) {
        if (!session || session.state !== 'entering')
            return;
        const input = activeInput();
        const userAns = choiceVal !== undefined ? choiceVal : (session.meta.signed ? Fa.parseSigned : Fa.parseAnswer)(input.value);
        if (Number.isNaN(userAns))
            return;
        const q = session.current.q;
        const correct = userAns === q.answer;
        const base = session.meta.mental ? session.current.answerShownAt : session.current.shownAt;
        const timeMs = Math.round(performance.now() - base);
        session.state = 'feedback';
        session.answers.push({ q, correct, timeMs, given: userAns });
        session.totalTimeMs += timeMs;
        if (correct) {
            session.correct++;
            session.combo++;
            session.bestCombo = Math.max(session.bestCombo, session.combo);
            if (session.bestTime == null || timeMs < session.bestTime)
                session.bestTime = timeMs;
            AudioFx.correct();
            input.classList.add('correct');
            if (session.combo > 0 && session.combo % 5 === 0)
                showCombo(session.combo);
        }
        else {
            session.wrong++;
            session.combo = 0;
            AudioFx.wrong();
            input.classList.add('wrong');
        }
        flashFeedback(correct);
        if (session.meta.choice)
            markChoices(userAns, q);
        if (session.meta.placement) {
            const t = q.type;
            session.placementResults[t] = session.placementResults[t] || { correct: 0, total: 0 };
            session.placementResults[t].total++;
            if (correct)
                session.placementResults[t].correct++;
        }
        else {
            const targetMs = Adaptive.TARGET_TIME_MS[q.type] || 3000;
            const xp = Progression.computeQuestionXP({ correct, timeMs, targetMs, comboAtThisPoint: session.combo, scale: (session.meta.choice ? 0.5 : 1) * (Sub.active() ? 3 : 1) });
            if (xp) {
                session.xpEarned += xp;
                const r = Progression.addXP(xp);
                if (r.leveledUp) {
                    Economy.add(Economy.CFG.levelUpCoins);
                    session.coins += Economy.CFG.levelUpCoins;
                    AudioFx.levelUp();
                    toast(`سطح ${Fa.num(r.info.level)}! ${Fa.num(Economy.CFG.levelUpCoins)} سکه جایزه گرفتی 🪙`);
                }
            }
            if (correct) {
                const mode = session.meta.choice ? 'choice4' : session.meta.mental ? 'mental' : '';
                const got = Economy.rollDrop({ type: q.type, mode, timeMs, targetMs }) + Economy.comboReward(session.combo);
                if (got) {
                    Economy.add(got);
                    session.coins += got;
                    toast(`+${Fa.num(got)} سکه 🪙`);
                }
            }
            updateHud();
            Adaptive.recordAnswer(q, correct, timeMs, { given: userAns, mc: !!session.meta.choice });
            Storage.saveSoon();
            if (session.meta.mental)
                Adaptive.adjustMentalTime(correct, timeMs);
        }
        el.hudCorrect.textContent = session.correct;
        el.hudWrong.textContent = session.wrong;
        if (!session.meta.choice)
            el.tapArea.classList.remove('hidden');
        advanceTimeout = setTimeout(() => advance(), session.meta.choice ? (correct ? 650 : 2800) : 620);
    }
    function advance() {
        clearTimeout(advanceTimeout);
        if (!session || session.state !== 'feedback')
            return;
        el.tapArea.classList.add('hidden');
        loadNext();
    }
    function showCombo(n) {
        el.combo.textContent = `🔥 Combo ×${n}`;
        el.combo.classList.add('show');
        AudioFx.combo();
        setTimeout(() => el.combo.classList.remove('show'), 900);
    }
    function flashFeedback(correct) {
        el.flash.className = 'feedback-flash ' + (correct ? 'correct' : 'wrong');
        void el.flash.offsetWidth;
        el.flash.classList.add('play');
    }
    function finish() {
        clearInterval(intervalHandle);
        clearTimeout(advanceTimeout);
        if (!session)
            return;
        stages(null);
        el.tapArea.classList.add('hidden');
        if (session.meta.placement)
            return finishPlacement();
        const total = session.correct + session.wrong;
        const accuracy = total ? session.correct / total : 0;
        const avgTime = total ? session.totalTimeMs / total : 0;
        const score = Math.max(0, session.correct * 10 - session.wrong * 4 + session.bestCombo * 2);
        const summary = {
            mode: session.mode, total, correct: session.correct, wrong: session.wrong,
            accuracy, avgTime, totalTimeMs: session.totalTimeMs, bestTime: session.bestTime,
            fastestAnswer: session.bestTime, bestCombo: session.bestCombo, xpEarned: session.xpEarned, score,
        };
        const done = Progression.addXP(20);
        summary.xpEarned += 20;
        if (done.leveledUp) {
            Economy.add(Economy.CFG.levelUpCoins);
            session.coins += Economy.CFG.levelUpCoins;
        }
        session.coins += Economy.add(Economy.sessionBonus(summary));
        summary.coins = session.coins;
        updateHud();
        const prevOfMode = Storage.data.sessionHistory.filter(s => s.mode === session.mode);
        const improved = Progression.updateRecords(summary);
        if (improved.length) {
            AudioFx.record();
        }
        Stats.recordSession(summary);
        if (session.meta.daily) {
            Progression.completeDailyChallenge({ correct: session.correct, total, timeMs: session.totalTimeMs });
            session.coins += Economy.add(Economy.CFG.dailyChallengeCoins);
            summary.coins = session.coins;
        }
        const agg = Stats.overallAggregate();
        agg.totalQuestions = agg.totalQuestions;
        agg.overallAccuracy = agg.overallAccuracy;
        const freshAchievements = Progression.checkAndUnlock({ ...agg, hasAnyRecord: agg.hasAnyRecord || improved.length > 0 });
        freshAchievements.forEach(a => { Economy.add(Economy.CFG.achievementCoins); summary.coins += Economy.CFG.achievementCoins; toast(`دستاورد جدید: ${a.icon} ${a.title}`); });
        Storage.save();
        renderResult(summary, improved, prevOfMode, { answers: session.answers, weakAtStart: session.weakAtStart });
        Router.navigate('result');
        session = null;
    }
    function finishPlacement() {
        let bestType = '1x1';
        for (const t of window.AppConst.TYPES) {
            const r = session.placementResults[t];
            if (r && r.total > 0 && r.correct / r.total >= 0.55)
                bestType = t;
        }
        Storage.data.adaptive.currentType = bestType;
        Storage.data.settings.manualLevel = String(window.AppConst.TYPES.indexOf(bestType) + 1);
        bindSettings();
        Storage.data.profile.placementDone = true;
        Storage.save();
        toast(`سطح اولیه تو تنظیم شد: ${Stats.TYPE_LABELS[bestType]}`);
        session = null;
        Router.navigate('home');
    }
    async function exit() {
        if (!session) {
            Router.navigate('home');
            return;
        }
        if (Dialog.isOpen())
            return;
        const ok = await Dialog.confirm('آیا مطمئنی می‌خواهی از تمرین خارج شوی؟ پیشرفت این تمرین ذخیره نمی‌شود.', 'خروج', 'ادامهٔ تمرین');
        if (!ok || !session)
            return;
        clearTimeout(countdownTimer);
        clearInterval(intervalHandle);
        clearTimeout(advanceTimeout);
        session = null;
        stages(null);
        Router.navigate('home');
    }
    function bindControls() {
        document.addEventListener('keydown', (e) => {
            if (Router.current !== 'practice' || !session)
                return;
            if (e.key === 'Escape') {
                exit();
                return;
            }
            if (e.key === 'Enter') {
                e.preventDefault();
                if (session.state === 'entering')
                    submit();
                else if (session.state === 'feedback')
                    advance();
            }
            else if (e.code === 'Space') {
                if (session.state === 'feedback') {
                    e.preventDefault();
                    advance();
                }
            }
        });
        el.answerInput.addEventListener('keydown', e => { if (e.key === 'Enter') {
            e.preventDefault();
            submit();
        } });
        el.mentalAnswerInput.addEventListener('keydown', e => { if (e.key === 'Enter') {
            e.preventDefault();
            submit();
        } });
        if (el.stage) {
            el.stage.addEventListener('click', () => {
                if (!session)
                    return;
                if (session.state === 'entering')
                    submit();
                else if (session.state === 'feedback')
                    advance();
            });
        }
        el.tapArea.addEventListener('click', () => {
            if (!session)
                return;
            if (session.state === 'entering')
                submit();
            else if (session.state === 'feedback')
                advance();
        });
    }
    function replay() { if (lastRun)
        start(lastRun.modeKey, lastRun.plan); }
    return { start, exit, bindControls, replay, canReplay: () => !!lastRun };
})();
function renderResult(summary, improved, prevOfMode, ctx) {
    Mascot.mount();
    $('[data-action="replay"]').classList.toggle('hidden', !UI.Practice.canReplay());
    $('[data-r="modeLabel"]').textContent = MODE_META[summary.mode].label;
    $('[data-r="total"]').textContent = summary.total;
    $('[data-r="correct"]').textContent = summary.correct;
    $('[data-r="wrong"]').textContent = summary.wrong;
    $('[data-r="accuracy"]').textContent = Stats.fmtPct(summary.accuracy);
    $('[data-r="avgTime"]').textContent = Stats.fmtTime(summary.avgTime);
    $('[data-r="bestTime"]').textContent = summary.bestTime != null ? Stats.fmtTime(summary.bestTime) : '—';
    $('[data-r="score"]').textContent = summary.score;
    $('[data-r="xp"]').textContent = '+' + summary.xpEarned;
    $('[data-r="coins"]').textContent = '+' + (summary.coins || 0);
    const recordCard = $('[data-r="recordCard"]');
    const recordText = $('[data-r="recordText"]');
    if (improved.length) {
        recordCard.style.display = '';
        const names = { fastestAnswer: 'سریع‌ترین پاسخ', bestAvgTime: 'بهترین میانگین زمان', bestAccuracy: 'بهترین دقت', bestStreak: 'بهترین Combo', bestXPSession: 'بیشترین XP یک تمرین', best30s: 'رکورد ۳۰ ثانیه', best60s: 'رکورد ۶۰ ثانیه', best20q: 'رکورد آزمون ۲۰ سؤالی' };
        recordText.textContent = `رکورد جدید ثبت شد: ${improved.map(k => names[k] || k).join('، ')} 🎉`;
    }
    else {
        recordCard.style.display = 'none';
    }
    const list = $('[data-r="coachList"]');
    list.innerHTML = '';
    Coach.sessionAnalysis(summary, prevOfMode, ctx).forEach(line => {
        const li = document.createElement('li');
        li.textContent = line;
        list.appendChild(li);
    });
    const sug = Coach.buildPlan();
    $('[data-r="nextSuggestion"]').textContent = sug.text;
    Router._nextSuggested = sug;
}
function renderProgress() {
    const p = Storage.data.profile;
    const info = Progression.levelInfo(p.totalXP);
    $('[data-pr="levelName"]').textContent = `سطح ${info.level} — ${info.name}`;
    $('[data-pr="xp"]').textContent = info.xpIntoLevel;
    $('[data-pr="xpNeed"]').textContent = info.xpForNext;
    $('[data-pr="levelBar"]').style.width = info.progressPct + '%';
    const agg = Stats.overallAggregate();
    $('[data-pr="totalSessions"]').textContent = agg.totalSessions;
    $('[data-pr="totalQ"]').textContent = agg.totalQuestions;
    $('[data-pr="accuracy"]').textContent = agg.totalQuestions ? Stats.fmtPct(agg.overallAccuracy) : '—';
    $('[data-pr="avgTime"]').textContent = agg.avgTime ? Stats.fmtTime(agg.avgTime) : '—';
    $('[data-pr="bestStreak"]').textContent = Storage.data.records.bestStreak;
    $('[data-pr="bestTime"]').textContent = Storage.data.records.fastestAnswer != null ? Stats.fmtTime(Storage.data.records.fastestAnswer) : '—';
    $('[data-pr="daysTrained"]').textContent = agg.daysTrained;
    $('[data-pr="bestAcc"]').textContent = Storage.data.records.bestAccuracy != null ? Stats.fmtPct(Storage.data.records.bestAccuracy) : '—';
    const typeBody = $('[data-pr="typeTable"]');
    typeBody.innerHTML = '';
    Stats.typeTableRows().forEach(r => {
        const tr = document.createElement('tr');
        tr.innerHTML = `<td>${r.label}</td><td>${r.acc != null ? Stats.fmtPct(r.acc) : '—'}</td><td>${r.avgT != null ? Stats.fmtTime(r.avgT) : '—'}</td><td><span class="badge-status ${r.status.cls}">${r.status.label}</span></td>`;
        typeBody.appendChild(tr);
    });
    const multBody = $('[data-pr="multTable"]');
    multBody.innerHTML = '';
    Stats.multTableRows().forEach(r => {
        const tr = document.createElement('tr');
        tr.innerHTML = `<td>×${r.mult}</td><td>${r.acc != null ? Stats.fmtPct(r.acc) : '—'}</td><td>${r.avgT != null ? Stats.fmtTime(r.avgT) : '—'}</td><td><span class="badge-status ${r.status.cls}">${r.status.label}</span></td>`;
        multBody.appendChild(tr);
    });
    const cf = Stats.compareToFirstDay();
    const cfList = $('[data-pr="compareFirst"]');
    cfList.innerHTML = '';
    if (cf) {
        [`⚡ ${cf.speedImprovementPct >= 0 ? cf.speedImprovementPct + '٪ سریع‌تر' : Math.abs(cf.speedImprovementPct) + '٪ کندتر'}`,
            `🎯 ${cf.accImprovementPct >= 0 ? cf.accImprovementPct + '٪ دقیق‌تر' : Math.abs(cf.accImprovementPct) + '٪ کم‌دقت‌تر'}`,
            `🧮 ${Math.max(0, cf.extraQuestions)} سؤال بیشتر حل کرده‌ای`].forEach(t => { const li = document.createElement('li'); li.textContent = t; cfList.appendChild(li); });
    }
    else {
        cfList.innerHTML = '<li>هنوز داده کافی نیست</li>';
    }
    const cw = Stats.compareToLastWeek();
    const cwList = $('[data-pr="compareWeek"]');
    cwList.innerHTML = '';
    if (cw) {
        [`سرعت: ${cw.speedPct >= 0 ? '+' : ''}${cw.speedPct}٪`, `دقت: ${cw.accPct >= 0 ? '+' : ''}${cw.accPct}٪`].forEach(t => { const li = document.createElement('li'); li.textContent = t; cwList.appendChild(li); });
    }
    else {
        cwList.innerHTML = '<li>هنوز داده کافی نیست</li>';
    }
    const achvGrid = $('[data-pr="achvGrid"]');
    achvGrid.innerHTML = '';
    Progression.ACHIEVEMENTS.forEach(a => {
        const unlocked = Storage.data.achievements.unlocked.includes(a.id);
        const div = document.createElement('div');
        div.className = 'achv' + (unlocked ? ' unlocked' : '');
        div.innerHTML = `<div class="ic">${a.icon}</div><b>${a.title}</b>`;
        achvGrid.appendChild(div);
    });
    const recBody = $('[data-pr="recordsTable"]');
    const r = Storage.data.records;
    const rows = [
        ['سریع‌ترین پاسخ', r.fastestAnswer != null ? Stats.fmtTime(r.fastestAnswer) : '—'],
        ['بهترین میانگین زمان', r.bestAvgTime != null ? Stats.fmtTime(r.bestAvgTime) : '—'],
        ['بهترین دقت', r.bestAccuracy != null ? Stats.fmtPct(r.bestAccuracy) : '—'],
        ['بیشترین Combo', r.bestStreak || '—'],
        ['بیشترین XP یک تمرین', r.bestXPSession || '—'],
        ['بهترین نتیجه ۳۰ ثانیه‌ای', r.best30s != null ? r.best30s + ' سؤال' : '—'],
        ['بهترین نتیجه ۶۰ ثانیه‌ای', r.best60s != null ? r.best60s + ' سؤال' : '—'],
        ['بهترین نتیجه آزمون ۲۰ سؤالی', r.best20q != null ? Stats.fmtTime(r.best20q) : '—'],
    ];
    recBody.innerHTML = rows.map(([k, v]) => `<tr><td style="text-align:right;">${k}</td><td><b>${v}</b></td></tr>`).join('');
    renderCharts();
}
function renderCharts() {
    const days = Object.keys(Storage.data.dailyStats).sort().slice(-14);
    const labels = days.map(d => Fa.jalaliDayFromKey(d));
    const speedVals = days.map(d => { const s = Storage.data.dailyStats[d]; return s.questions ? s.totalTime / s.questions : null; });
    const accVals = days.map(d => { const s = Storage.data.dailyStats[d]; return s.questions ? Math.round((s.correct / s.questions) * 100) : null; });
    const volVals = days.map(d => Storage.data.dailyStats[d].questions);
    Charts.lineChart($('[data-chart="speed"]'), labels, speedVals);
    Charts.lineChart($('[data-chart="accuracy"]'), labels, accVals, { color: '#1c9a6c' });
    Charts.barChart($('[data-chart="volume"]'), labels, volVals);
    const typeLabels = window.AppConst.TYPES.map(t => Stats.TYPE_LABELS[t]);
    const typeVals = window.AppConst.TYPES.map(t => {
        const s = Storage.data.typeStats[t];
        return s.attempts ? s.correct / s.attempts : 0.05;
    });
    Charts.radarChart($('[data-chart="skill"]'), typeLabels, typeVals);
}
function bindSettings() {
    const s = Storage.data.settings;
    $('[data-set="mentalDisplayTime"]').value = s.mentalDisplayTime;
    $('[data-set="questionCount"]').value = s.questionCount;
    $('[data-set="examTime"]').value = s.examTime;
    $('[data-set="manualLevel"]').value = s.manualLevel;
    $('[data-set="grade"]').value = String(s.grade);
    $('[data-set="primeRange"]').value = String(s.primeRange);
    $('[data-set="soundOn"]').checked = s.soundOn;
    if (!bindSettings._done)
        $$('[data-set]').forEach(input => {
            input.addEventListener('change', () => {
                const key = input.dataset.set;
                let val = input.type === 'checkbox' ? input.checked : input.value;
                if (['mentalDisplayTime', 'questionCount', 'examTime'].includes(key))
                    val = Number(val);
                Storage.data.settings[key] = val;
                Storage.save();
                toast('تنظیمات ذخیره شد');
            });
        });
    bindSettings._done = true;
}
window.UI = { Router, Practice, updateHud, renderHome, renderProgress, bindSettings, toast };
