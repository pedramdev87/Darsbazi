(function () {
    var bar = document.getElementById('bar');
    var top = document.getElementById('top');
    var hero = document.getElementById('hero');
    var ticking = false;
    function onScroll() {
        var y = window.pageYOffset || document.documentElement.scrollTop || 0;
        var h = document.documentElement.scrollHeight - window.innerHeight;
        var p = h > 0 ? Math.min(1, Math.max(0, y / h)) : 0;
        bar.style.transform = 'scaleX(' + p + ')';
        top.classList.toggle('show', y > hero.offsetHeight * 0.55);
        ticking = false;
    }
    window.addEventListener('scroll', function () {
        if (!ticking) {
            ticking = true;
            requestAnimationFrame(onScroll);
        }
    }, { passive: true });
    window.addEventListener('resize', onScroll);
    onScroll();
    var pending = Array.prototype.slice.call(document.querySelectorAll('.reveal'));
    function revealCheck() {
        var limit = window.innerHeight * 0.92;
        pending = pending.filter(function (el) {
            if (el.getBoundingClientRect().top < limit) {
                el.classList.add('in');
                return false;
            }
            return true;
        });
    }
    window.addEventListener('scroll', revealCheck, { passive: true });
    window.addEventListener('resize', revealCheck);
    window.addEventListener('load', revealCheck);
    revealCheck();
    var mascot = document.getElementById('mascot');
    var pupils = mascot.querySelectorAll('.m-pupil');
    function look(x, y) {
        var r = mascot.getBoundingClientRect();
        var dx = (x - (r.left + r.width / 2)) / (window.innerWidth / 2);
        var dy = (y - (r.top + r.height / 2)) / (window.innerHeight / 2);
        var tx = Math.max(-1, Math.min(1, dx)) * 3.2;
        var ty = Math.max(-1, Math.min(1, dy)) * 3.2;
        for (var i = 0; i < pupils.length; i++)
            pupils[i].style.transform = 'translate(' + tx + 'px,' + ty + 'px)';
    }
    window.addEventListener('pointermove', function (e) { look(e.clientX, e.clientY); }, { passive: true });
    mascot.addEventListener('click', function () {
        mascot.classList.remove('jump');
        void mascot.offsetWidth;
        mascot.classList.add('jump');
    });
})();
