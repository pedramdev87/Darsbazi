const AudioFx = (() => {
    let ctx = null;
    let silent = null;
    const AC = window.AudioContext || window.webkitAudioContext;
    function getCtx() {
        if (ctx && ctx.state === 'closed')
            ctx = null;
        if (!ctx && AC)
            ctx = new AC({ latencyHint: 'interactive' });
        return ctx;
    }
    function wake() {
        const c = getCtx();
        if (!c)
            return null;
        if (c.state !== 'running') {
            try {
                const p = c.resume();
                if (p && p.catch)
                    p.catch(() => { });
            }
            catch (e) { }
        }
        return c;
    }
    const isIOS = /iP(hone|ad|od)/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
    function primeIOS() {
        if (!isIOS || silent)
            return;
        try {
            silent = new Audio('data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAESsAABErAAABAAgAZGF0YQAAAAA=');
            silent.loop = true;
            silent.volume = 0.01;
            const p = silent.play();
            if (p && p.catch)
                p.catch(() => { silent = null; });
        }
        catch (e) {
            silent = null;
        }
    }
    function unlockOnGesture() {
        const c = wake();
        primeIOS();
        if (c && c.state === 'running') {
            const b = c.createBuffer(1, 1, 22050);
            const s = c.createBufferSource();
            s.buffer = b;
            s.connect(c.destination);
            s.start(0);
        }
    }
    ['pointerdown', 'touchstart', 'touchend', 'click', 'keydown'].forEach((ev) => {
        document.addEventListener(ev, unlockOnGesture, { capture: true, passive: true });
    });
    document.addEventListener('visibilitychange', () => { if (!document.hidden)
        wake(); });
    window.addEventListener('pageshow', wake);
    window.addEventListener('focus', wake);
    function enabled() {
        return Storage.data.settings.soundOn;
    }
    function schedule(c, { freq, duration, type, gain, delay }) {
        const t0 = c.currentTime + delay + 0.01;
        const osc = c.createOscillator();
        const g = c.createGain();
        osc.type = type;
        osc.frequency.setValueAtTime(freq, t0);
        g.gain.setValueAtTime(0.0001, t0);
        g.gain.linearRampToValueAtTime(gain, t0 + 0.012);
        g.gain.exponentialRampToValueAtTime(0.001, t0 + duration);
        osc.connect(g).connect(c.destination);
        osc.start(t0);
        osc.stop(t0 + duration + 0.03);
    }
    function tone({ freq = 440, duration = 0.12, type = 'sine', gain = 0.08, delay = 0 }) {
        if (!enabled())
            return;
        const c = getCtx();
        if (!c)
            return;
        const job = { freq, duration, type, gain, delay };
        if (c.state === 'running') {
            schedule(c, job);
            return;
        }
        let p;
        try {
            p = c.resume();
        }
        catch (e) {
            return;
        }
        if (p && p.then)
            p.then(() => { if (c.state === 'running')
                schedule(c, job); }).catch(() => { });
    }
    return {
        unlock: unlockOnGesture,
        start() { tone({ freq: 523, duration: 0.15 }); tone({ freq: 659, duration: 0.18, delay: 0.06 }); },
        correct() { tone({ freq: 880, duration: 0.1, type: 'triangle' }); },
        wrong() { tone({ freq: 180, duration: 0.18, type: 'sawtooth', gain: 0.06 }); },
        tick() { tone({ freq: 1200, duration: 0.03, gain: 0.02 }); },
        record() { tone({ freq: 660, duration: 0.12 }); tone({ freq: 880, duration: 0.12, delay: 0.09 }); tone({ freq: 1100, duration: 0.2, delay: 0.18 }); },
        levelUp() { tone({ freq: 523, duration: 0.14 }); tone({ freq: 659, duration: 0.14, delay: 0.1 }); tone({ freq: 784, duration: 0.22, delay: 0.2 }); },
        combo() { tone({ freq: 990, duration: 0.09, type: 'triangle' }); },
    };
})();
window.AudioFx = AudioFx;
