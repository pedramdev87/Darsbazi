const Coach = (() => {
    const { TYPE_LABELS, fmtTime, fmtPct } = Stats;
    const F = Fa;
    const TARGET_1x1 = Adaptive.TARGET_TIME_MS['1x1'];
    const ltr = (s) => `\u2066${s}\u2069`;
    const factLabel = (key) => {
        const [lo, hi] = QuestionGenerator.parseKey(key);
        return ltr(F.toFa(`${lo}×${hi}`));
    };
    const multLabel = (m) => ltr(F.toFa(`×${m}`));
    const joinFa = (items) => {
        if (items.length <= 1)
            return items.join('');
        return items.slice(0, -1).join('، ') + ' و ' + items[items.length - 1];
    };
    const mean = (arr) => arr.reduce((a, b) => a + b, 0) / (arr.length || 1);
    const median = (arr) => {
        if (!arr.length)
            return null;
        const s = arr.slice().sort((a, b) => a - b);
        const m = Math.floor(s.length / 2);
        return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
    };
    const clamp = (x, lo, hi) => Math.max(lo, Math.min(hi, x));
    function factRows() {
        const facts = Storage.data.factStats;
        const rows = [];
        for (const [key, s] of Object.entries(facts)) {
            if (!s || !s.attempts)
                continue;
            const [lo, hi] = QuestionGenerator.parseKey(key);
            const recent = s.recent || [];
            let wSum = 0, wErr = 0;
            recent.forEach(r => { const w = r.m ? 0.5 : 1; wSum += w; wErr += w * (r.c ? 0 : 1); });
            const lifeErr = (s.wrong + 0.5) / (s.attempts + 1);
            const recentErr = (wErr + 0.25) / (wSum + 0.5);
            const err = recent.length ? 0.35 * lifeErr + 0.65 * recentErr : lifeErr;
            const okTimes = recent.filter(r => r.c && !r.m).map(r => r.t);
            const avgT = s.totalTime / s.attempts;
            const recentAvgT = okTimes.length ? mean(okTimes) : avgT;
            const top = Object.entries(s.wrongAns || {}).sort((a, b) => b[1] - a[1])[0];
            rows.push({
                key, lo, hi, n: s.attempts, wrong: s.wrong || 0, err, avgT, recentAvgT,
                lastWrong: recent.length > 0 && !recent[recent.length - 1].c,
                topWrong: top ? { v: Number(top[0]), count: top[1] } : null,
            });
        }
        const med = median(rows.filter(r => r.n >= 2).map(r => r.recentAvgT));
        const baseline = Math.max(med || TARGET_1x1, TARGET_1x1 * 0.8);
        rows.forEach(r => {
            r.slowRatio = r.recentAvgT / baseline;
            r.errorFlag = r.wrong >= 1 && r.err >= 0.3;
            r.slowFlag = r.n >= 2 && r.slowRatio >= 1.4 && r.recentAvgT > TARGET_1x1;
            r.score = r.err * 3 + clamp(r.slowRatio - 1, 0, 1.5) * 1.2 + (r.lastWrong ? 0.4 : 0);
        });
        return rows;
    }
    function weakFacts(limit = 4) {
        return factRows()
            .filter(r => r.errorFlag || r.slowFlag)
            .sort((a, b) => b.score - a.score)
            .slice(0, limit);
    }
    function weakKeys(limit = 6) { return weakFacts(limit).map(f => f.key); }
    function reasonFor(f) {
        const parts = [];
        if (f.errorFlag) {
            let t = `${F.num(f.wrong)} بار از ${F.num(f.n)} بار غلط`;
            if (f.topWrong)
                t += ` (بیشتر ${F.num(f.topWrong.v)} جواب دادی؛ درست: ${F.num(f.lo * f.hi)})`;
            parts.push(t);
            if (f.slowFlag)
                parts.push(`و کند هم هست (${fmtTime(f.recentAvgT)})`);
        }
        else {
            parts.push(`درست جواب می‌دهی ولی کند (${fmtTime(f.recentAvgT)})`);
        }
        return parts.join(' ');
    }
    function strongMultipliers(limit = 2) {
        const ms = Storage.data.multiplierStats;
        return AppConst.MULTIPLIERS
            .map(m => ({ m, ...ms[m] }))
            .filter(x => x.attempts >= 8 && x.correct / x.attempts >= 0.95 && x.totalTime / x.attempts <= 2200)
            .sort((a, b) => a.totalTime / a.attempts - b.totalTime / b.attempts)
            .slice(0, limit)
            .map(x => ({ m: x.m, acc: x.correct / x.attempts, avgT: x.totalTime / x.attempts }));
    }
    function recentTrend() {
        const list = Storage.data.sessionHistory.filter(s => s.total >= 5);
        if (list.length < 2)
            return null;
        const k = Math.min(3, Math.floor(list.length / 2));
        const cur = list.slice(-k), prev = list.slice(-2 * k, -k);
        if (!prev.length)
            return null;
        const agg = (arr) => {
            const q = arr.reduce((a, s) => a + s.total, 0);
            return {
                acc: arr.reduce((a, s) => a + s.accuracy * s.total, 0) / q,
                time: arr.reduce((a, s) => a + s.avgTime * s.total, 0) / q,
            };
        };
        const a = agg(cur), b = agg(prev);
        return {
            speedPct: b.time ? Math.round(((b.time - a.time) / b.time) * 100) : 0,
            accPts: Math.round((a.acc - b.acc) * 100),
        };
    }
    function buildPlan() {
        const type = Adaptive.currentType();
        const count = 20;
        const weak = weakFacts(4);
        const plan = { mode: 'adaptive', count, type, kind: 'general', focusFacts: [], focusMults: [], chips: [], text: '' };
        if (type === '1x1' && weak.length) {
            plan.kind = 'facts';
            plan.focusFacts = weak.map(f => f.key);
            plan.chips = weak.map(f => factLabel(f.key));
            plan.text = `${F.num(count)} سؤال ${TYPE_LABELS[type]} با تمرکز روی ضرب‌های ${joinFa(plan.chips)}`;
            return plan;
        }
        if (QuestionGenerator.HAS_SINGLE_DIGIT[type]) {
            const wm = Adaptive.weakestMultipliers(2).filter(w => w.acc < 0.92 || w.avgT > 3000);
            if (wm.length) {
                plan.kind = 'mults';
                plan.focusMults = wm.map(w => w.m);
                plan.chips = wm.map(w => multLabel(w.m));
                plan.text = `${F.num(count)} سؤال ${TYPE_LABELS[type]} با تمرکز روی ضرب‌های ${joinFa(plan.chips)}`;
                return plan;
            }
        }
        else if (weak.length) {
            plan.kind = 'basics';
            plan.type = '1x1';
            plan.focusFacts = weak.map(f => f.key);
            plan.chips = weak.map(f => factLabel(f.key));
            plan.text = `مرور پایه: ${F.num(count)} سؤال ${TYPE_LABELS['1x1']} روی ضرب‌های ${joinFa(plan.chips)} (قبل از ادامهٔ ${TYPE_LABELS[type]})`;
            return plan;
        }
        const hasData = Stats.overallAggregate().totalQuestions >= 5;
        plan.text = hasData
            ? `${F.num(count)} سؤال ${TYPE_LABELS[type]} با تمرکز روی سرعت`
            : `${F.num(count)} سؤال ${TYPE_LABELS[type]} تا نقاط قوت و ضعفت را بشناسم`;
        return plan;
    }
    function homeInsightsBase() {
        const lines = [];
        const agg = Stats.overallAggregate();
        const plan = buildPlan();
        const weak = weakFacts(3);
        if (agg.totalQuestions < 5) {
            lines.push({ kind: 'head', text: 'هنوز داده‌ی کافی ندارم. یک تمرین ۲۰ سؤالی بزن تا ضرب‌های ضعیف و قوی‌ات را پیدا کنم.' });
            lines.push({ kind: 'plan', text: `تمرین پیشنهادی: ${plan.text}.` });
            return lines;
        }
        if (weak.length) {
            lines.push({ kind: 'head', text: 'این ضرب‌ها الان بیشتر از بقیه به تمرین نیاز دارند:' });
            weak.forEach(f => lines.push({ kind: 'fact', text: `${factLabel(f.key)} — ${reasonFor(f)}` }));
        }
        else {
            lines.push({ kind: 'good', text: 'الان ضرب پایهٔ مشخصی که اذیتت کند ندارم؛ کارت عالی است.' });
        }
        const wm = Adaptive.weakestMultipliers(1)[0];
        if (wm && (wm.acc < 0.9 || wm.avgT > 3000)) {
            const inWeak = weak.filter(f => f.lo === Number(wm.m) || f.hi === Number(wm.m)).length;
            if (inWeak >= 2 || !weak.length) {
                lines.push({ kind: 'table', text: `ضعیف‌ترین جدولت ${multLabel(wm.m)} است (دقت ${fmtPct(wm.acc)}، میانگین ${fmtTime(wm.avgT)}).` });
            }
        }
        const strong = strongMultipliers(2);
        if (strong.length) {
            lines.push({ kind: 'good', text: `ضرب‌های ${joinFa(strong.map(s => multLabel(s.m)))} را عالی بلدی (دقت بالا و سرعت زیاد).` });
        }
        const trend = recentTrend();
        if (trend) {
            if (trend.speedPct >= 5)
                lines.push({ kind: 'trend', text: `نسبت به تمرین‌های قبلی ${F.num(trend.speedPct)}٪ سریع‌تر شده‌ای.` });
            else if (trend.speedPct <= -8)
                lines.push({ kind: 'trend', text: `سرعتت اخیراً ${F.num(-trend.speedPct)}٪ کمتر شده؛ کوتاه و پشت‌سرهم تمرین کن.` });
            if (trend.accPts >= 3)
                lines.push({ kind: 'trend', text: `دقتت ${F.num(trend.accPts)} درصد بهتر شده است.` });
            else if (trend.accPts <= -5)
                lines.push({ kind: 'trend', text: 'دقتت اخیراً افت کرده؛ کمی آهسته‌تر و دقیق‌تر جواب بده.' });
        }
        const type = Adaptive.currentType();
        const ts = Storage.data.typeStats[type];
        if (!weak.length && ts.attempts >= 30 && ts.correct / ts.attempts >= 0.92 && ts.totalTime / ts.attempts <= Adaptive.TARGET_TIME_MS[type]
            && Storage.data.settings.manualLevel !== 'auto' && AppConst.TYPES.indexOf(type) < AppConst.TYPES.length - 1) {
            const next = AppConst.TYPES[AppConst.TYPES.indexOf(type) + 1];
            lines.push({ kind: 'good', text: `برای سطح ${TYPE_LABELS[type]} آماده‌ای؛ از تنظیمات می‌توانی سطح ${TYPE_LABELS[next]} را امتحان کنی.` });
        }
        if (agg.currentDayStreak >= 2) {
            lines.push({ kind: 'trend', text: `${F.num(agg.currentDayStreak)} روز پشت‌سرهم تمرین کرده‌ای؛ زنجیره‌ات را نشکن!` });
        }
        lines.push({ kind: 'plan', text: `تمرین پیشنهادی: ${plan.text}.` });
        return lines.slice(0, 8);
    }
    function sessionAnalysisBase(summary, prevSessionsOfSameMode, ctx = {}) {
        const lines = [];
        const answers = ctx.answers || [];
        if (summary.accuracy >= 0.95)
            lines.push('دقتت عالی بود؛ همین‌طور ادامه بده.');
        else if (summary.accuracy < 0.7)
            lines.push('روی دقت بیشتر از سرعت تمرکز کن تا پایه‌ات محکم‌تر شود.');
        else
            lines.push(`دقت ${fmtPct(summary.accuracy)}؛ با کمی تمرین به ${F.num(95)}٪ می‌رسی.`);
        if (prevSessionsOfSameMode && prevSessionsOfSameMode.length) {
            const prev = prevSessionsOfSameMode[prevSessionsOfSameMode.length - 1];
            if (prev.avgTime && summary.avgTime) {
                const diffPct = Math.round(((prev.avgTime - summary.avgTime) / prev.avgTime) * 100);
                if (diffPct > 3)
                    lines.push(`سرعتت نسبت به تمرین قبلی ${F.num(diffPct)}٪ بهتر شد.`);
                else if (diffPct < -3)
                    lines.push('سرعتت نسبت به تمرین قبلی کمی کندتر بود؛ نگران نباش، ادامه بده.');
            }
        }
        const wrongMap = new Map();
        answers.filter(a => !a.correct).forEach(a => {
            if (!wrongMap.has(a.q.display))
                wrongMap.set(a.q.display, a);
        });
        if (wrongMap.size) {
            const items = [...wrongMap.values()].slice(0, 3).map(a => `${ltr(a.q.display)} = ${F.num(a.q.answer)}`);
            lines.push(`این‌ها را غلط زدی؛ جواب درستشان را یادت بماند: ${joinFa(items)}.`);
        }
        if (ctx.weakAtStart && ctx.weakAtStart.length) {
            const improved = ctx.weakAtStart.filter(key => {
                const mine = answers.filter(a => a.q.key === key);
                return mine.length >= 2 && mine.every(a => a.correct);
            });
            if (improved.length) {
                lines.push(`در ${joinFa(improved.slice(0, 3).map(factLabel))} که ضعیف بودی، این بار همه را درست زدی. دارد جا می‌افتد!`);
            }
        }
        const okAns = answers.filter(a => a.correct);
        if (okAns.length >= 5) {
            const slow = okAns.reduce((m, a) => (a.timeMs > m.timeMs ? a : m), okAns[0]);
            const avg = mean(okAns.map(a => a.timeMs));
            const tgt = Adaptive.TARGET_TIME_MS[slow.q.type] || 3000;
            if (slow.timeMs > avg * 1.6 && slow.timeMs > tgt * 1.2) {
                lines.push(`کندترین جواب درستت ${ltr(slow.q.display)} بود (${fmtTime(slow.timeMs)}).`);
            }
        }
        if (answers.length >= 10) {
            const half = Math.floor(answers.length / 2);
            const t1 = mean(answers.slice(0, half).map(a => a.timeMs));
            const t2 = mean(answers.slice(half).map(a => a.timeMs));
            const ratio = t2 / t1;
            if (ratio >= 1.25)
                lines.push(`در نیمهٔ دوم تمرین ${F.num(Math.round((ratio - 1) * 100))}٪ کندتر شدی؛ تمرین‌های کوتاه‌تر ولی بیشتر در روز بهتر جواب می‌دهد.`);
            else if (ratio <= 0.8)
                lines.push(`نیمهٔ دوم ${F.num(Math.round((1 - ratio) * 100))}٪ سریع‌تر بود؛ ذهنت گرم شده بود، قبل از تمرین اصلی چند سؤال آسان بزن.`);
        }
        return lines.slice(0, 6);
    }
    function strategy(a, b) {
        const f = (x) => F.num(x);
        if (a === 9 || b === 9) {
            const x = a === 9 ? b : a;
            return ltr(`${f(x)}×۹ = ${f(x)}×۱۰ − ${f(x)} = ${f(x * 10)} − ${f(x)} = ${f(x * 9)}`);
        }
        if (a === 5 || b === 5) {
            const x = a === 5 ? b : a;
            return ltr(`${f(x)}×۵ = نصفِ ${f(x)}×۱۰ = نصفِ ${f(x * 10)} = ${f(x * 5)}`);
        }
        if (b >= 7)
            return ltr(`${f(a)}×${f(b)} = ${f(a)}×۱۰ − ${f(a)}×${f(10 - b)} = ${f(a * 10)} − ${f(a * (10 - b))} = ${f(a * b)}`);
        if (b === 6)
            return ltr(`${f(a)}×۶ = ${f(a)}×۵ + ${f(a)} = ${f(a * 5)} + ${f(a)} = ${f(a * 6)}`);
        return ltr(`${f(a)}×${f(b)} = ${f(b)} بار جمعِ ${f(a)} = ${f(a * b)}`);
    }
    function diagnose(f) {
        if (!f.topWrong)
            return '';
        const v = f.topWrong.v, truth = f.lo * f.hi;
        for (let p = 1; p <= 9; p++)
            for (let q = p; q <= 9; q++) {
                if (p * q === v && (Math.abs(p - f.lo) + Math.abs(q - f.hi) === 1 || Math.abs(p - f.hi) + Math.abs(q - f.lo) === 1)) {
                    return `پرتکرارترین خطا ${F.num(v)} است که همان ${ltr(F.toFa(`${p}×${q}`))} است؛ یعنی جدولِ مجاور را به‌جای این ضرب بازیابی می‌کنی.`;
                }
            }
        if (Math.abs(v - truth) <= 2)
            return `پرتکرارترین خطا ${F.num(v)} است و تنها ${F.num(Math.abs(v - truth))} واحد با پاسخ درست فاصله دارد؛ احتمالاً خطای جمعِ پایانی است.`;
        if (v % f.lo === 0 || v % f.hi === 0)
            return `پرتکرارترین خطا ${F.num(v)} است که مضرب یکی از عامل‌هاست؛ گام آخرِ محاسبه را کامل نمی‌کنی.`;
        return `پرتکرارترین خطا ${F.num(v)} است و با هیچ ضرب مجاوری نمی‌خواند؛ نشانهٔ حدس‌زدن است.`;
    }
    function profHome() {
        const rows = factRows(), weak = weakFacts(4), plan = buildPlan();
        const total = rows.reduce((s, r) => s + r.n, 0);
        if (total < 15)
            return [
                { kind: 'head', text: 'درود بر تو. برای تدوین کارنامهٔ تخصصی دست‌کم ۱۵ پاسخ ثبت‌شده لازم است؛ نخست یک تمرین ۲۰ سؤالی را به انجام برسان تا الگوی خطا و سرعتت را برآورد کنم.' },
                { kind: 'plan', text: `برنامهٔ آغازین: ${plan.text}.` },
            ];
        const wrong = rows.reduce((s, r) => s + r.wrong, 0);
        const flagged = rows.filter(r => r.errorFlag || r.slowFlag).length;
        const lines = [{ kind: 'head', text: `بر پایهٔ ${F.num(total)} پاسخ ثبت‌شده، دقت تجمعی ${fmtPct(1 - wrong / total)} است و ${F.num(flagged)} ضرب از ${F.num(rows.length)} ضرب بررسی‌شده نیازمند مداخله است.` }];
        weak.forEach((f, i) => {
            const parts = [`${F.num(i + 1)}) ${factLabel(f.key)}: ${F.num(f.n)} تلاش، ${F.num(f.wrong)} خطا (دقت ${fmtPct(1 - f.wrong / f.n)})، میانگین پاسخ ${fmtTime(f.recentAvgT)} (${F.num(f.slowRatio, 1)} برابر میانهٔ تو).`];
            const dg = diagnose(f);
            if (dg)
                parts.push(dg);
            parts.push('راهبرد حل: ' + strategy(f.lo, f.hi) + '.');
            lines.push({ kind: 'fact', text: parts.join(' ') });
        });
        const wm = Adaptive.weakestMultipliers(1)[0];
        if (wm)
            lines.push({ kind: 'table', text: `در سطح جدول، ${multLabel(wm.m)} با دقت ${fmtPct(wm.acc)} و میانگین ${fmtTime(wm.avgT)} ضعیف‌ترین است.` });
        const tr = recentTrend();
        if (tr)
            lines.push({ kind: 'trend', text: `روند سه تمرین اخیر نسبت به سه تمرین پیشین: سرعت ${tr.speedPct >= 0 ? '+' : '−'}${F.num(Math.abs(tr.speedPct))}٪ و دقت ${tr.accPts >= 0 ? '+' : '−'}${F.num(Math.abs(tr.accPts))} واحد درصد.` });
        lines.push({ kind: 'plan', text: `نسخهٔ تجویزی: ${plan.text}؛ حدود ${F.num(70)}٪ پرسش‌ها بر اهداف بالا و بقیه برای مرور فاصله‌دار.` });
        return lines;
    }
    function profSession(summary, prev, ctx) {
        const base = sessionAnalysisBase(summary, prev, ctx), answers = ctx.answers || [];
        const out = [`ارزیابی این جلسه: دقت ${fmtPct(summary.accuracy)} و میانگین زمان ${fmtTime(summary.avgTime)} برای ${F.num(summary.total)} پرسش.`];
        const ok = answers.filter(a => a.correct), bad = answers.filter(a => !a.correct);
        if (ok.length >= 3 && bad.length >= 1) {
            const to = mean(ok.map(a => a.timeMs)), tb = mean(bad.map(a => a.timeMs));
            out.push(tb < to * 0.8
                ? `پاسخ‌های غلطت به‌طور میانگین ${fmtTime(to - tb)} سریع‌تر از پاسخ‌های درستت بودند؛ این نشانهٔ شتاب‌زدگی است نه ندانستن؛ پیش از ثبت یک ثانیه مکث کن.`
                : tb > to * 1.3
                    ? `پاسخ‌های غلطت کندتر بودند (${fmtTime(tb)} در برابر ${fmtTime(to)}). مسئله در بازیابی از حافظه است نه بی‌دقتی؛ مرور هدفمند همین ضرب‌ها را تجویز می‌کنم.`
                    : 'زمان پاسخ‌های درست و غلط تقریباً برابر است؛ خطاها تصادفی‌اند و ریشهٔ ساختاری ندارند.');
        }
        bad.filter(a => a.q.type === '1x1' && Number.isFinite(a.given)).slice(0, 3).forEach((a) => {
            const f = { lo: Math.min(a.q.a, a.q.b), hi: Math.max(a.q.a, a.q.b), topWrong: { v: a.given } };
            out.push(`${ltr(a.q.display)} = ${F.num(a.q.answer)}؛ تو ${F.num(a.given)} نوشتی. ${diagnose(f)} راهبرد: ${strategy(f.lo, f.hi)}.`);
        });
        return out.concat(base.slice(1)).slice(0, 8);
    }
    const homeInsights = () => (Mascot.isProf() ? profHome() : homeInsightsBase());
    const sessionAnalysis = (summary, prev, ctx = {}) => (Mascot.isProf() ? profSession(summary, prev, ctx) : sessionAnalysisBase(summary, prev, ctx));
    return { factRows, weakFacts, weakKeys, strongMultipliers, buildPlan, homeInsights, sessionAnalysis, factLabel, reasonFor };
})();
window.Coach = Coach;
