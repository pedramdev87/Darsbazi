const Stats = (() => {
    const { TYPES, MULTIPLIERS, todayKey } = window.AppConst;
    const TYPE_LABELS = { '1x1': '۱×۱', '2x1': '۲×۱', '2x2': '۲×۲', '3x1': '۳×۱', '3x2': '۳×۲', '3x3': '۳×۳' };
    function fmtTime(ms) {
        if (ms == null || isNaN(ms))
            return '—';
        return Fa.num(ms / 1000, 1) + ' ثانیه';
    }
    function fmtPct(x) {
        if (x == null || isNaN(x))
            return '—';
        return Fa.num(Math.round(x * 100)) + '٪';
    }
    function recordSession(summary) {
        const key = Storage.touchToday();
        const day = Storage.data.dailyStats[key];
        day.questions += summary.total;
        day.correct += summary.correct;
        day.wrong += summary.wrong;
        day.totalTime += summary.totalTimeMs;
        day.xp += summary.xpEarned;
        Storage.data.sessionHistory.push({
            date: Date.now(),
            mode: summary.mode,
            total: summary.total,
            correct: summary.correct,
            wrong: summary.wrong,
            accuracy: summary.accuracy,
            avgTime: summary.avgTime,
            xpEarned: summary.xpEarned,
            score: summary.score,
        });
    }
    function overallAggregate() {
        const days = Storage.data.dailyStats;
        let totalQuestions = 0, correct = 0, wrong = 0, totalTime = 0;
        Object.values(days).forEach(d => {
            totalQuestions += d.questions;
            correct += d.correct;
            wrong += d.wrong;
            totalTime += d.totalTime;
        });
        const overallAccuracy = totalQuestions ? correct / totalQuestions : 0;
        const avgTime = totalQuestions ? totalTime / totalQuestions : null;
        const totalSessions = Storage.data.sessionHistory.length;
        const hasAnyRecord = Object.values(Storage.data.records).some(v => v != null && v !== 0);
        return {
            totalQuestions, correct, wrong, overallAccuracy, avgTime, totalSessions, hasAnyRecord,
            currentDayStreak: computeDayStreak(),
            daysTrained: Storage.data.daysTrainedSet.length,
        };
    }
    function computeDayStreak() {
        const set = new Set(Storage.data.daysTrainedSet);
        let streak = 0;
        let d = new Date();
        if (!set.has(todayKey(d)))
            d.setDate(d.getDate() - 1);
        while (set.has(todayKey(d))) {
            streak++;
            d.setDate(d.getDate() - 1);
        }
        return streak;
    }
    function typeStatusLabel(acc, avgT, target) {
        if (acc == null)
            return { label: 'بدون داده', cls: 'badge-mid' };
        if (acc >= 0.9 && avgT <= target * 1.1)
            return { label: 'عالی', cls: 'badge-good' };
        if (acc >= 0.75)
            return { label: 'خوب', cls: 'badge-good' };
        if (acc >= 0.55)
            return { label: 'نیاز به تمرین', cls: 'badge-mid' };
        return { label: 'ضعیف', cls: 'badge-bad' };
    }
    function typeTableRows() {
        return TYPES.map(t => {
            const s = Storage.data.typeStats[t];
            const acc = s.attempts ? s.correct / s.attempts : null;
            const avgT = s.attempts ? s.totalTime / s.attempts : null;
            const status = typeStatusLabel(acc, avgT, Adaptive.TARGET_TIME_MS[t]);
            return { type: t, label: TYPE_LABELS[t], acc, avgT, attempts: s.attempts, status };
        });
    }
    function multTableRows() {
        return MULTIPLIERS.map(m => {
            const s = Storage.data.multiplierStats[m];
            const acc = s.attempts ? s.correct / s.attempts : null;
            const avgT = s.attempts ? s.totalTime / s.attempts : null;
            const status = typeStatusLabel(acc, avgT, 2200);
            return { mult: m, acc, avgT, attempts: s.attempts, status };
        });
    }
    function compareToFirstDay() {
        const days = Object.keys(Storage.data.dailyStats).sort();
        if (days.length < 2)
            return null;
        const firstDays = days.slice(0, Math.min(3, days.length));
        const recentDays = days.slice(-Math.min(3, days.length));
        const agg = (list) => {
            let q = 0, c = 0, t = 0;
            list.forEach(k => { const d = Storage.data.dailyStats[k]; q += d.questions; c += d.correct; t += d.totalTime; });
            return { q, acc: q ? c / q : 0, avgT: q ? t / q : 0 };
        };
        const first = agg(firstDays), recent = agg(recentDays);
        if (!first.q || !recent.q)
            return null;
        const speedImprovementPct = first.avgT ? Math.round(((first.avgT - recent.avgT) / first.avgT) * 100) : 0;
        const accImprovementPct = Math.round((recent.acc - first.acc) * 100);
        const extraQuestions = overallAggregate().totalQuestions - first.q;
        return { speedImprovementPct, accImprovementPct, extraQuestions };
    }
    function compareToLastWeek() {
        const days = Object.keys(Storage.data.dailyStats).sort();
        const now = new Date();
        const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        const inLastNDays = (n, offset = 0) => days.filter(k => {
            const [y, m, dd] = k.split('-').map(Number);
            const diff = Math.round((startOfToday - new Date(y, m - 1, dd)) / 86400000);
            return diff >= offset && diff < offset + n;
        });
        const thisWeekDays = inLastNDays(7, 0);
        const lastWeekDays = inLastNDays(7, 7);
        const agg = (list) => {
            let q = 0, c = 0, t = 0;
            list.forEach(k => { const d = Storage.data.dailyStats[k]; q += d.questions; c += d.correct; t += d.totalTime; });
            return { q, acc: q ? c / q : 0, avgT: q ? t / q : 0 };
        };
        const a = agg(thisWeekDays), b = agg(lastWeekDays);
        if (!a.q || !b.q)
            return null;
        return {
            speedPct: b.avgT ? Math.round(((b.avgT - a.avgT) / b.avgT) * 100) : 0,
            accPct: Math.round((a.acc - b.acc) * 100),
        };
    }
    return {
        fmtTime, fmtPct, TYPE_LABELS,
        recordSession, overallAggregate, computeDayStreak,
        typeTableRows, multTableRows, typeStatusLabel,
        compareToFirstDay, compareToLastWeek,
    };
})();
window.Stats = Stats;
