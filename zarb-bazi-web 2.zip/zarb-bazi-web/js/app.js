(function () {
    document.addEventListener('DOMContentLoaded', init);
    function init() {
        Storage.load();
        Economy.sanitize();
        Themes.applyEquipped();
        Mascot.mount();
        Economy.onChange(() => UI.updateHud());
        Fa.watch(document.body);
        [$('[data-el="answerInput"]'), $('[data-el="mentalAnswerInput"]')].forEach(Fa.bindDigitInput);
        UI.updateHud();
        Shop.bind();
        Sub.apply();
        Advanced.bindSign();
        Pad.bind();
        UI.bindSettings();
        UI.Practice.bindControls();
        wireNav();
        wireHome();
        wirePracticeExit();
        wireResult();
        wireSettingsActions();
        wireOnboarding();
        wireBackup();
        UI.renderHome();
        registerServiceWorker();
        document.addEventListener('pointerdown', () => AudioFx.unlock(), { once: true });
    }
    function wireNav() {
        $$('[data-nav] button, [data-nav-mobile] button').forEach(btn => {
            btn.addEventListener('click', () => UI.Router.navigate(btn.dataset.route));
        });
    }
    function wireHome() {
        $('[data-mode-grid]').addEventListener('click', (e) => {
            const card = e.target.closest('[data-mode]');
            if (!card)
                return;
            UI.Practice.start(card.dataset.mode);
        });
        $('[data-action="start-suggested"]').addEventListener('click', () => {
            UI.Practice.start('adaptive', Coach.buildPlan());
        });
    }
    function wirePracticeExit() {
        $('[data-action="exit-practice"]').addEventListener('click', () => UI.Practice.exit());
    }
    function wireResult() {
        $('[data-action="back-home"]').addEventListener('click', () => UI.Router.navigate('home'));
        $('[data-action="replay"]').addEventListener('click', () => UI.Practice.replay());
        $('[data-action="start-next-suggested"]').addEventListener('click', () => {
            UI.Practice.start('adaptive', Coach.buildPlan());
        });
    }
    function wireSettingsActions() {
        $('[data-action="reset-data"]').addEventListener('click', async () => {
            const ok = await Dialog.confirm('این کار همه اطلاعات تمرین، رکوردها، سکه‌ها و XP شما را برای همیشه پاک می‌کند. دکمهٔ تأیید بعد از ۵ ثانیه فعال می‌شود.', 'پاک کن', 'انصراف', { wait: 5 });
            if (!ok)
                return;
            const go = await Dialog.grace('پاک‌سازی تا چند ثانیهٔ دیگر انجام می‌شود:', 5, 'لغو پاک‌سازی');
            if (!go) {
                toast('پاک‌سازی لغو شد');
                return;
            }
            Storage.reset();
            Economy.sanitize();
            Themes.applyEquipped();
            Sub.apply();
            Mascot.mount();
            UI.updateHud();
            UI.bindSettings();
            toast('اطلاعات پاک‌سازی شد');
            UI.Router.navigate('home');
        });
    }
    function wireOnboarding() {
        const overlay = $('[data-el="onboard"]');
        if (!overlay) {
            Storage.data.profile.onboardingDone = true;
            Storage.data.profile.placementDone = true;
            Storage.save();
            return;
        }
        const slides = $$('.ob-slide', overlay), dots = $$('[data-ob="dots"] i', overlay);
        const back = $('[data-ob="back"]'), next = $('[data-ob="next"]'), fin = $('[data-ob="final"]');
        let step = 0;
        const show = () => {
            slides.forEach((s, i) => s.classList.toggle('on', i === step));
            dots.forEach((d, i) => d.classList.toggle('on', i === step));
            const last = step === slides.length - 1;
            back.style.visibility = step === 0 ? 'hidden' : 'visible';
            $('.ob-nav', overlay).classList.toggle('hidden', last);
            fin.classList.toggle('hidden', !last);
        };
        back.addEventListener('click', () => { if (step > 0) {
            step--;
            show();
        } });
        next.addEventListener('click', () => { if (step < slides.length - 1) {
            step++;
            show();
        } });
        const done = () => {
            Storage.data.profile.onboardingDone = true;
            Storage.data.profile.placementDone = true;
            Storage.save();
            overlay.classList.add('hidden');
        };
        $('[data-action="start-placement"]').addEventListener('click', () => { done(); Storage.data.profile.placementDone = false; UI.Practice.start('placement'); });
        $('[data-action="skip-placement"]').addEventListener('click', done);
        if (!Storage.data.profile.onboardingDone) {
            show();
            overlay.classList.remove('hidden');
        }
    }
    function wireBackup() {
        const text = $('[data-bk="text"]'), acts = $('[data-bk="actions"]'), file = $('[data-bk="file"]');
        const payload = async () => {
            const me = await Device.id();
            const body = JSON.stringify({ app: 'zarb-bazi', v: 2, id: me.display, exportedAt: Date.now(), data: Storage.data });
            return JSON.stringify({ body, mac: await Device.mac(body) });
        };
        const restore = async (raw) => {
            let obj, inner;
            try {
                obj = JSON.parse(raw);
                inner = JSON.parse(obj.body);
            }
            catch (e) {
                return toast('فایل پشتیبان معتبر نیست');
            }
            if (!inner || inner.app !== 'zarb-bazi' || !inner.data || !inner.data.profile)
                return toast('این فایل مربوط به ضرب بازی نیست');
            const me = await Device.id();
            if (inner.id !== me.display)
                return toast('این پشتیبان مال شناسهٔ دیگری است و روی این گوشی کار نمی‌کند');
            if (obj.mac !== await Device.mac(obj.body))
                return toast('فایل پشتیبان دست‌کاری شده است');
            if (!await Dialog.confirm('همهٔ اطلاعات فعلی با پشتیبان جایگزین می‌شود. ادامه می‌دهی؟', 'بازیابی', 'انصراف'))
                return;
            Storage.replaceAll(inner.data);
            Economy.sanitize();
            Themes.applyEquipped();
            Sub.apply();
            Mascot.mount();
            UI.updateHud();
            UI.bindSettings();
            text.classList.add('hidden');
            acts.classList.add('hidden');
            toast('پشتیبان بازیابی شد');
            UI.Router.navigate('home');
        };
        $('[data-bk="export"]').addEventListener('click', async () => {
            const json = await payload();
            text.value = json;
            text.classList.remove('hidden');
            acts.classList.remove('hidden');
            try {
                const url = URL.createObjectURL(new Blob([json], { type: 'application/json' }));
                const el = document.createElement('a');
                el.href = url;
                el.download = 'zarb-bazi-backup.json';
                document.body.appendChild(el);
                el.click();
                el.remove();
                setTimeout(() => URL.revokeObjectURL(url), 2000);
            }
            catch (e) { }
            Storage.data.meta.lastBackupAt = Date.now();
            Storage.save();
            toast('پشتیبان آماده است؛ اگر دانلود نشد، متن را کپی کن');
        });
        $('[data-bk="import"]').addEventListener('click', () => { text.value = ''; text.classList.remove('hidden'); acts.classList.remove('hidden'); file.click(); });
        file.addEventListener('change', () => {
            const f = file.files && file.files[0];
            if (!f)
                return;
            const r = new FileReader();
            r.onload = () => restore(String(r.result));
            r.readAsText(f);
            file.value = '';
        });
        $('[data-bk="apply"]').addEventListener('click', () => restore(text.value));
        $('[data-bk="copy"]').addEventListener('click', async () => {
            try {
                await navigator.clipboard.writeText(text.value);
                toast('کپی شد');
            }
            catch (e) {
                text.select();
                toast('متن را انتخاب و کپی کن');
            }
        });
    }
    function registerServiceWorker() {
        if ('serviceWorker' in navigator && location.protocol.indexOf('http') === 0) {
            window.addEventListener('load', () => {
                navigator.serviceWorker.register('sw.js').catch(() => { });
            });
        }
    }
})();
