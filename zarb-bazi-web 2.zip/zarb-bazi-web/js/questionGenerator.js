const QuestionGenerator = (() => {
    function randInt(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }
    function shuffle(arr) {
        const a = arr.slice();
        for (let i = a.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [a[i], a[j]] = [a[j], a[i]];
        }
        return a;
    }
    const RANGES = {
        '1x1': [[1, 9], [1, 9]],
        '2x1': [[10, 99], [1, 9]],
        '2x2': [[10, 99], [10, 99]],
        '3x1': [[100, 999], [1, 9]],
        '3x2': [[100, 999], [10, 99]],
        '3x3': [[100, 999], [100, 999]],
    };
    const HAS_SINGLE_DIGIT = { '1x1': true, '2x1': true, '3x1': true, '2x2': false, '3x2': false, '3x3': false };
    function factKey(a, b) {
        const lo = Math.min(a, b), hi = Math.max(a, b);
        return `${lo}x${hi}`;
    }
    function parseKey(key) {
        const [lo, hi] = String(key).split('x').map(Number);
        return [lo, hi];
    }
    function build(a, b, type) {
        return {
            a, b, type,
            answer: a * b,
            key: factKey(a, b),
            display: Fa.toFa(`${a} × ${b}`),
        };
    }
    function generateForType(type, opts = {}) {
        const [ra, rb] = RANGES[type] || RANGES['1x1'];
        let a, b;
        if (type === '1x1' && opts.forceFact) {
            [a, b] = parseKey(opts.forceFact);
            if (Math.random() < 0.5)
                [a, b] = [b, a];
            return build(a, b, type);
        }
        if (opts.biasMultiplier && HAS_SINGLE_DIGIT[type]) {
            const m = Number(opts.biasMultiplier);
            if (type === '1x1') {
                a = m;
                b = randInt(1, 9);
                if (Math.random() < 0.5)
                    [a, b] = [b, a];
                return build(a, b, type);
            }
            a = randInt(ra[0], ra[1]);
            b = m;
            return build(a, b, type);
        }
        a = randInt(ra[0], ra[1]);
        b = randInt(rb[0], rb[1]);
        if (Math.random() < 0.5 && ra[0] === rb[0] && ra[1] === rb[1])
            [a, b] = [b, a];
        return build(a, b, type);
    }
    function isTooRepetitive(candidate, recentKeys) {
        if (recentKeys.length === 0)
            return false;
        const last = recentKeys[recentKeys.length - 1];
        if (last === candidate.key)
            return true;
        if (recentKeys.length >= 3) {
            const [k1, k2] = recentKeys.slice(-2);
            if (k1 === candidate.key && k2 === last)
                return true;
        }
        return false;
    }
    function generate(type, opts = {}) {
        const recentKeys = opts.recentKeys || [];
        let candidate, tries = 0;
        do {
            candidate = generateForType(type, opts);
            tries++;
        } while (isTooRepetitive(candidate, recentKeys) && tries < 8 && !opts.forceFact);
        return candidate;
    }
    function makeChoices(q, opts = {}) {
        const { a, b, answer } = q;
        const seen = new Set([answer]);
        const picked = [];
        const add = (v) => {
            v = Number(v);
            if (Number.isInteger(v) && v > 0 && !seen.has(v)) {
                seen.add(v);
                picked.push(v);
                return true;
            }
            return false;
        };
        shuffle(opts.pastWrong || []).slice(0, 1).forEach(add);
        const near = shuffle([(a + 1) * b, (a - 1) * b, a * (b + 1), a * (b - 1), (a + 2) * b, a * (b + 2), (a - 2) * b, a * (b - 2)]);
        for (const v of near) {
            if (picked.length >= 2)
                break;
            add(v);
        }
        const s = String(answer);
        const swapped = s.length >= 2 ? Number(s.slice(0, -2) + s[s.length - 1] + s[s.length - 2]) : NaN;
        const tier3 = shuffle([answer + 10, answer - 10, answer + 2, answer - 2, swapped, answer + a, answer - b]);
        for (const v of tier3) {
            if (picked.length >= 3)
                break;
            add(v);
        }
        for (const v of near) {
            if (picked.length >= 3)
                break;
            add(v);
        }
        let guard = 0;
        while (picked.length < 3 && guard++ < 200) {
            const spread = Math.max(6, Math.round(answer * 0.25));
            add(answer + randInt(-spread, spread));
        }
        while (picked.length < 3)
            add(answer + 100 + picked.length * 7);
        const options = shuffle([answer, ...picked.slice(0, 3)]);
        return { options, correctIndex: options.indexOf(answer) };
    }
    return { generate, factKey, parseKey, makeChoices, shuffle, RANGES, HAS_SINGLE_DIGIT };
})();
window.QuestionGenerator = QuestionGenerator;
