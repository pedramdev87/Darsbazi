const Device = (() => {
    const ALPHA = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789', SALT = 'zarb-bazi:v1:', enc = new TextEncoder();
    const hasSubtle = !!(window.crypto && crypto.subtle);
    const b64u = (u8) => btoa(String.fromCharCode(...u8)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    const unb64u = (s) => Uint8Array.from(atob(s.replace(/-/g, '+').replace(/_/g, '/')), c => c.charCodeAt(0));
    async function sha(s) {
        if (hasSubtle)
            return new Uint8Array(await crypto.subtle.digest('SHA-256', enc.encode(s)));
        let h1 = 0xdeadbeef, h2 = 0x41c6ce57;
        const out = new Uint8Array(8);
        for (let i = 0; i < s.length; i++) {
            const c = s.charCodeAt(i);
            h1 = Math.imul(h1 ^ c, 2654435761);
            h2 = Math.imul(h2 ^ c, 1597334677);
        }
        new DataView(out.buffer).setUint32(0, h1 >>> 0);
        new DataView(out.buffer).setUint32(4, h2 >>> 0);
        return out;
    }
    async function raw() {
        try {
            if (window.ZarbNative && ZarbNative.getDeviceId) {
                const v = await ZarbNative.getDeviceId();
                if (v)
                    return 'native:' + v;
            }
        }
        catch (e) { }
        try {
            const C = window.Capacitor;
            if (C && C.Plugins && C.Plugins.Device) {
                const r = await C.Plugins.Device.getId();
                const v = r && (r.identifier || r.uuid);
                if (v)
                    return 'native:' + v;
            }
        }
        catch (e) { }
        let gl = '';
        try {
            const c = document.createElement('canvas').getContext('webgl');
            const x = c.getExtension('WEBGL_debug_renderer_info');
            gl = x ? c.getParameter(x.UNMASKED_RENDERER_WEBGL) : '';
        }
        catch (e) { }
        const s = window.screen || {};
        return ['fp', Math.max(s.width, s.height), Math.min(s.width, s.height), window.devicePixelRatio, navigator.hardwareConcurrency, navigator.deviceMemory || '', Intl.DateTimeFormat().resolvedOptions().timeZone, gl].join('|');
    }
    let cache = null;
    async function id() {
        if (cache)
            return cache;
        const h = await sha(SALT + await raw());
        let n = 0n;
        for (let i = 0; i < 8; i++)
            n = (n << 8n) | BigInt(h[i % h.length]);
        n >>= 4n;
        let t = '';
        for (let i = 11; i >= 0; i--)
            t += ALPHA[Number((n >> BigInt(i * 5)) & 31n)];
        return (cache = { packed: n, text: t, display: `ZB-${t.slice(0, 4)}-${t.slice(4, 8)}-${t.slice(8)}` });
    }
    async function mac(text) {
        const me = await id();
        if (!hasSubtle)
            return b64u(await sha('mac:' + me.text + text));
        const key = await crypto.subtle.importKey('raw', enc.encode(SALT + 'backup:' + me.text), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
        return b64u(new Uint8Array(await crypto.subtle.sign('HMAC', key, enc.encode(text))));
    }
    const PUB = { "kty": "EC", "crv": "P-256", "x": "B5CIUFlVtHmV-COpBerA8wtIZKzpHlne6dkWianFI-k", "y": "8N0VT7lAMP32bmzX-J72CcIit6Hs_XaF2ETibW-2o0w" };
    async function redeemSigned(text) {
        const bad = { ok: false, reason: 'bad' };
        try {
            if (!hasSubtle)
                return { ok: false, reason: 'nocrypto' };
            const bytes = unb64u(text.replace(/\s+/g, '').slice(4));
            if (bytes.length !== 85 || bytes[0] !== 1)
                return bad;
            const payload = bytes.slice(0, 21), sig = bytes.slice(21);
            const key = await crypto.subtle.importKey('jwk', PUB, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
            if (!await crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, key, sig, payload))
                return bad;
            const dv = new DataView(payload.buffer);
            if (dv.getBigUint64(1) !== (await id()).packed)
                return { ok: false, reason: 'device' };
            const tag = 'n:' + [...payload.slice(15)].map(x => x.toString(16).padStart(2, '0')).join('');
            const used = Storage.data.shop.redeemed;
            if (used.includes(tag))
                return { ok: false, reason: 'used' };
            used.push(tag);
            const coins = dv.getUint32(9), days = dv.getUint16(13);
            if (coins)
                Economy.add(coins);
            if (days)
                Sub.activateDays(days);
            Storage.save();
            return { ok: true, coins, subDays: days };
        }
        catch (e) {
            return bad;
        }
    }
    return { id, mac, redeemSigned };
})();
window.Device = Device;
