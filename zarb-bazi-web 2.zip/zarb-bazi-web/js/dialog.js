const Dialog = (() => {
    let root, msg, yes, no, resolver = null, timer = null;
    const isOpen = () => !!resolver;
    function done(v) { if (!resolver)
        return; const r = resolver; resolver = null; root.classList.add('hidden'); r(v); }
    function init() {
        root = document.querySelector('[data-el="dlg"]');
        msg = root.querySelector('[data-dlg="msg"]');
        yes = root.querySelector('[data-dlg="yes"]');
        no = root.querySelector('[data-dlg="no"]');
        yes.addEventListener('click', () => done(true));
        no.addEventListener('click', () => done(false));
        root.addEventListener('click', (e) => { if (e.target === root)
            done(false); });
        document.addEventListener('keydown', (e) => { if (isOpen() && e.key === 'Escape') {
            e.stopPropagation();
            done(false);
        } }, true);
    }
    function confirm(text, okText = 'بله', cancelText = 'انصراف', opts = {}) {
        if (!root)
            init();
        if (resolver)
            done(false);
        msg.textContent = text;
        no.textContent = cancelText;
        root.classList.remove('hidden');
        clearInterval(timer);
        let left = Number(opts.wait) || 0;
        const paint = () => { yes.textContent = left > 0 ? `${okText} (${Fa.num(left)})` : okText; yes.disabled = left > 0; };
        paint();
        if (left > 0) {
            timer = setInterval(() => { left--; paint(); if (left <= 0)
                clearInterval(timer); }, 1000);
            no.focus();
        }
        else
            yes.focus();
        return new Promise((res) => { resolver = (v) => { clearInterval(timer); res(v); }; });
    }
    function grace(text, seconds, cancelText = 'لغو') {
        return new Promise((res) => {
            const bar = document.createElement('div');
            bar.className = 'undo-bar';
            let left = seconds;
            const label = document.createElement('span');
            const btn = document.createElement('button');
            const fill = document.createElement('i');
            btn.className = 'btn';
            btn.textContent = cancelText;
            bar.append(label, btn, fill);
            document.body.appendChild(bar);
            fill.style.animationDuration = seconds + 's';
            const paint = () => { label.textContent = `${text} ${Fa.num(left)}`; };
            paint();
            const t = setInterval(() => { left--; if (left <= 0) {
                clearInterval(t);
                bar.remove();
                res(true);
            }
            else
                paint(); }, 1000);
            btn.addEventListener('click', () => { clearInterval(t); bar.remove(); res(false); });
        });
    }
    return { confirm, grace, isOpen };
})();
window.Dialog = Dialog;
