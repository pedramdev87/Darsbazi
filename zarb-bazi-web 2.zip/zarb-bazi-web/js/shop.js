const Shop = (() => {
    let timer = null;
    const $s = (s) => document.querySelector(s);
    function card(t) {
        const owned = Economy.ownsTheme(t.id), eq = Economy.equippedTheme() === t.id;
        const price = t.price ? `<span class="price">🪙 ${Fa.group(t.price)}</span>` : '<span class="price">رایگان</span>';
        const btns = owned
            ? (eq ? '<button class="btn" disabled>فعال ✓</button>' : `<button class="btn btn-primary" data-act="equip" data-id="${t.id}">استفاده</button>`)
            : `<button class="btn btn-primary" data-act="buy" data-id="${t.id}">خرید</button><button class="btn" data-act="preview" data-id="${t.id}">پیش‌نمایش</button>`;
        return `<div class="theme-card ${t.tier === 'premium' ? 'premium' : ''} ${eq ? 'equipped' : ''}"><div class="sw" data-t="${t.id}"></div><h3>${t.name}${t.subOnly ? ' 👑' : t.tier === 'premium' ? ' ✨' : ''}</h3><p>${t.desc}</p>${owned ? '<span class="price">' + (eq ? 'در حال استفاده' : 'مال توست') + '</span>' : price}<div class="row">${btns}</div></div>`;
    }
    const RB = '@a________rm_____d';
    async function renderSub() {
        const on = Sub.active(), me = await Device.id();
        $s('[data-shop="sub"]').innerHTML = `<h3>👑 اشتراک ضرب بازی</h3><p class="sub-status">${Sub.statusText()}</p><ul class="perks">${Sub.PERKS.map(p => '<li>' + p + '</li>').join('')}</ul><div class="sub-price">${Fa.group(Sub.PRICE)} تومان</div><div class="sub-steps"><b>روش خرید</b><ol><li>شناسهٔ اپلیکیشن خودت را کپی کن:<div class="id-line" dir="ltr" data-latin>${me.display}</div></li><li>به آیدی روبیکا <span class="id-line" dir="ltr" data-latin>${RB}</span> پیام بده و شناسه‌ات را بفرست.</li><li>یک کد می‌گیری؛ آن را پایین همین صفحه، در بخش «کد هدیه» وارد کن.</li></ol><div class="row"><button class="btn" data-act="copyid">کپی شناسهٔ من</button><button class="btn" data-act="copyrb">کپی آیدی روبیکا</button></div></div>`;
    }
    async function copy(text, ok) {
        try {
            await navigator.clipboard.writeText(text);
            toast(ok);
        }
        catch (e) {
            toast(text);
        }
    }
    function coachCard(k) {
        const sh = Storage.data.shop, owned = sh.coachOwned.includes(k.id), eq = sh.coachEquipped === k.id;
        const btn = owned ? (eq ? '<button class="btn" disabled>فعال ✓</button>' : `<button class="btn btn-primary" data-act="equipc" data-id="${k.id}">استفاده</button>`) : `<button class="btn btn-primary" data-act="buyc" data-id="${k.id}">خرید</button>`;
        const status = owned ? `<span class="price">${eq ? 'مربی فعلی' : 'مال توست'}</span>` : `<span class="price">${k.price ? '🪙 ' + Fa.group(k.price) : 'رایگان'}</span>`;
        return `<div class="theme-card ${k.special ? 'special' : ''} ${eq ? 'equipped' : ''}"><div class="mascot-prev">${Mascot.svg(k.id)}</div><h3>${k.name}${k.special ? ' 🎓' : ''}</h3><p>${k.desc}</p>${status}<div class="row">${btn}</div></div>`;
    }
    function render() {
        const cg = $s('[data-shop="coaches"]');
        if (cg)
            cg.innerHTML = Mascot.SKINS.map(coachCard).join('');
        renderSub();
        Device.id().then(m => { const el = $s('[data-shop="appid"]'); if (el)
            el.textContent = m.display; });
        $s('[data-shop="balance"]').textContent = Economy.balance();
        const part = (tier) => Themes.CATALOG.filter(t => (tier === 'premium') === (t.tier === 'premium')).map(card).join('');
        $s('[data-shop="normal"]').innerHTML = part('normal');
        $s('[data-shop="premium"]').innerHTML = part('premium');
        UI.updateHud();
    }
    function preview(id) {
        clearTimeout(timer);
        Themes.startPreview(id);
        toast('پیش‌نمایش ۸ ثانیه‌ای تم');
        timer = setTimeout(() => { Themes.endPreview(); }, 8000);
    }
    function act(a, id) {
        if (a === 'copyid')
            return Device.id().then(m => copy(m.display, 'شناسه کپی شد'));
        if (a === 'copyrb')
            return copy(RB, 'آیدی روبیکا کپی شد');
        if (a === 'equipc') {
            Economy.equipCoach(id);
            Mascot.mount();
            toast('مربی عوض شد');
            return render();
        }
        if (a === 'buyc') {
            const r = Economy.buyCoach(id);
            if (r.ok) {
                Mascot.mount();
                AudioFx.levelUp();
                toast(`«${r.coach.name}» مربی تو شد 🎉`);
            }
            else if (r.reason === 'poor')
                toast(`${Fa.group(r.missing)} سکهٔ دیگر لازم داری`);
            return render();
        }
        if (a === 'preview')
            return preview(id);
        clearTimeout(timer);
        Themes.endPreview();
        if (a === 'equip') {
            Economy.equipTheme(id);
            Themes.applyEquipped();
            toast('تم فعال شد');
        }
        if (a === 'buy') {
            const r = Economy.buyTheme(id);
            if (r.ok) {
                Themes.applyEquipped();
                AudioFx.levelUp();
                toast(`«${r.theme.name}» مال توست 🎉`);
            }
            else if (r.reason === 'sub')
                toast('این تم فقط با اشتراک قابل خرید است 👑');
            else if (r.reason === 'poor')
                toast(`${Fa.group(r.missing)} سکهٔ دیگر لازم داری`);
        }
        render();
    }
    async function redeem() {
        const inp = $s('[data-shop="code"]');
        const r = await Economy.redeemAsync(inp.value);
        if (r.ok) {
            inp.value = '';
            AudioFx.record();
            const parts = [];
            if (r.coins)
                parts.push(`${Fa.group(r.coins)} سکه 🪙`);
            if (r.subDays)
                parts.push(`${Fa.num(r.subDays)} روز اشتراک 👑`);
            toast('دریافت شد: ' + parts.join(' و '));
        }
        else
            toast({ empty: 'کد را وارد کن', invalid: 'کد معتبر نیست', used: 'این کد قبلاً استفاده شده', bad: 'کد معتبر نیست یا دست‌کاری شده', device: 'این کد برای گوشی دیگری ساخته شده', nocrypto: 'این دستگاه از کدهای امضاشده پشتیبانی نمی‌کند' }[r.reason] || 'کد معتبر نیست');
        render();
    }
    function bind() {
        $s('#view-shop').addEventListener('click', (e) => {
            const b = e.target.closest('[data-act]');
            if (b)
                act(b.dataset.act, b.dataset.id);
            else if (e.target.closest('[data-shop="redeem"]'))
                redeem();
            else if (e.target.closest('[data-shop="copyid"]'))
                Device.id().then(m => copy(m.display, 'شناسه کپی شد'));
        });
        $s('[data-shop="code"]').addEventListener('keydown', (e) => { if (e.key === 'Enter')
            redeem(); });
    }
    return { render, bind };
})();
window.Shop = Shop;
