const STORAGE_KEY = 'zarbBazi:v1';
const LEGACY_KEYS = ['sorobanApp:v1'];
const MAX_HISTORY_DAYS = 60;
const MAX_QUESTION_LOG = 400;
const TYPES = ['1x1', '2x1', '2x2', '3x1', '3x2', '3x3'];
const MULTIPLIERS = ['2', '3', '4', '5', '6', '7', '8', '9'];
function todayKey(d = new Date()) {
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}
function emptyTypeStat() {
    return { attempts: 0, correct: 0, totalTime: 0, recentAcc: [], recentTime: [] };
}
function emptyMultStat() {
    return { attempts: 0, correct: 0, totalTime: 0 };
}
function defaultData() {
    return {
        version: 2,
        createdAt: Date.now(),
        profile: {
            onboardingDone: false,
            placementDone: false,
            totalXP: 0,
            level: 1,
            coins: 0,
            coinsEarned: 0,
        },
        settings: {
            mentalDisplayTime: 3000,
            questionCount: 20,
            examTime: 60,
            manualLevel: '1',
            soundOn: true,
            grade: '7',
            primeRange: '100',
            fxOn: true,
        },
        records: {
            fastestAnswer: null,
            bestAvgTime: null,
            bestAccuracy: null,
            bestStreak: 0,
            bestXPSession: 0,
            best30s: null,
            best60s: null,
            best20q: null,
        },
        dailyStats: {},
        typeStats: Object.fromEntries(TYPES.map(t => [t, emptyTypeStat()])),
        multiplierStats: Object.fromEntries(MULTIPLIERS.map(m => [m, emptyMultStat()])),
        factStats: {},
        sessionHistory: [],
        recentQuestions: [],
        achievements: { unlocked: [] },
        dailyChallenge: { date: null, target: null, completed: false, result: null },
        adaptive: {
            currentType: '1x1',
            typeWeights: { '1x1': 1, '2x1': 0, '3x1': 0, '2x2': 0, '3x2': 0, '3x3': 0 },
        },
        shop: { owned: ['classic'], equipped: 'classic', redeemed: [], coachOwned: ['classic'], coachEquipped: 'classic' },
        sub: { until: 0 },
        meta: { lastBackupAt: null },
        daysTrainedSet: [],
    };
}
const BLOCKED_KEYS = new Set(['__proto__', 'constructor', 'prototype']);
const isPlain = (x) => x !== null && typeof x === 'object' && !Array.isArray(x);
const cloneJSON = (x) => (x === undefined ? undefined : JSON.parse(JSON.stringify(x)));
function deepMerge(base, extra) {
    if (Array.isArray(base))
        return Array.isArray(extra) ? cloneJSON(extra) : base.slice();
    if (!isPlain(base)) {
        if (extra === undefined)
            return base;
        if (base === null)
            return cloneJSON(extra);
        return typeof extra === typeof base ? extra : base;
    }
    const src = isPlain(extra) ? extra : {};
    const out = {};
    if (Object.keys(base).length === 0) {
        for (const k of Object.keys(src)) {
            if (BLOCKED_KEYS.has(k))
                continue;
            out[k] = cloneJSON(src[k]);
        }
        return out;
    }
    for (const k of Object.keys(base))
        out[k] = deepMerge(base[k], src[k]);
    return out;
}
const Storage = {
    _data: null,
    _saveTimer: null,
    load() {
        if (this._data)
            return this._data;
        const def = defaultData();
        let raw = null;
        let fromLegacy = false;
        try {
            raw = localStorage.getItem(STORAGE_KEY);
            if (!raw) {
                for (const k of LEGACY_KEYS) {
                    raw = localStorage.getItem(k);
                    if (raw) {
                        fromLegacy = true;
                        break;
                    }
                }
            }
        }
        catch (e) {
            raw = null;
        }
        if (!raw) {
            this._data = def;
            return this._data;
        }
        try {
            this._data = deepMerge(def, JSON.parse(raw));
        }
        catch (e) {
            console.warn('داده ذخیره‌شده خراب بود؛ یک نسخه از آن نگه داشته و داده تازه ساخته شد.', e);
            try {
                localStorage.setItem(STORAGE_KEY + ':corrupt', raw);
            }
            catch (_) { }
            this._data = def;
        }
        this._normalize();
        if (fromLegacy)
            this.save();
        return this._data;
    },
    _normalize() {
        const d = this._data;
        for (const key of Object.keys(d.factStats)) {
            const [lo, hi] = key.split('x').map(Number);
            const s = d.factStats[key];
            if (!(lo >= 1 && hi <= 9) || !isPlain(s)) {
                delete d.factStats[key];
                continue;
            }
            s.attempts = Number(s.attempts) || 0;
            s.correct = Number(s.correct) || 0;
            s.totalTime = Number(s.totalTime) || 0;
            s.wrong = Number.isFinite(s.wrong) ? s.wrong : Math.max(0, s.attempts - s.correct);
            s.recent = Array.isArray(s.recent) ? s.recent.slice(-6) : [];
            s.wrongAns = isPlain(s.wrongAns) ? s.wrongAns : {};
            s.last = Number(s.last) || 0;
        }
        const p = d.profile;
        p.coins = Math.max(0, Math.floor(Number(p.coins) || 0));
        p.coinsEarned = Math.max(0, Math.floor(Number(p.coinsEarned) || 0));
        p.totalXP = Math.max(0, Math.floor(Number(p.totalXP) || 0));
        if (!TYPES.includes(d.adaptive.currentType))
            d.adaptive.currentType = '1x1';
        const ml = String(d.settings.manualLevel);
        d.settings.manualLevel = (ml === 'auto' || (Number(ml) >= 1 && Number(ml) <= TYPES.length)) ? ml : '1';
    },
    save() {
        if (!this._data)
            return;
        clearTimeout(this._saveTimer);
        this._saveTimer = null;
        const days = Object.keys(this._data.dailyStats).sort();
        if (days.length > MAX_HISTORY_DAYS) {
            const drop = days.slice(0, days.length - MAX_HISTORY_DAYS);
            drop.forEach(d => delete this._data.dailyStats[d]);
        }
        if (this._data.sessionHistory.length > 100) {
            this._data.sessionHistory = this._data.sessionHistory.slice(-100);
        }
        if (this._data.recentQuestions.length > MAX_QUESTION_LOG) {
            this._data.recentQuestions = this._data.recentQuestions.slice(-MAX_QUESTION_LOG);
        }
        try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(this._data));
        }
        catch (e) {
            console.error('ذخیره‌سازی ناموفق بود', e);
        }
    },
    saveSoon(ms = 400) {
        if (this._saveTimer)
            return;
        this._saveTimer = setTimeout(() => this.save(), ms);
    },
    get data() { return this.load(); },
    reset() {
        const keep = this._data && this._data.shop ? this._data.shop.redeemed.slice() : [];
        this._data = defaultData();
        this._data.shop.redeemed = keep;
        this._data.profile.onboardingDone = true;
        this.save();
    },
    replaceAll(obj) {
        this._data = deepMerge(defaultData(), obj);
        this._normalize();
        this.save();
        return this._data;
    },
    touchToday() {
        const key = todayKey();
        if (!this.data.daysTrainedSet.includes(key))
            this.data.daysTrainedSet.push(key);
        if (!this.data.dailyStats[key]) {
            this.data.dailyStats[key] = { questions: 0, correct: 0, wrong: 0, totalTime: 0, xp: 0 };
        }
        return key;
    },
};
window.Storage = Storage;
window.AppConst = { TYPES, MULTIPLIERS, todayKey, emptyTypeStat, emptyMultStat, defaultData, deepMerge };
