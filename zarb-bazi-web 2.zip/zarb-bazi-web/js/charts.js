const Charts = (() => {
    const DEFAULT_H = 160;
    function setupCanvas(canvas) {
        const dpr = Math.min(window.devicePixelRatio || 1, 3);
        const cssH = Number(canvas.dataset.h) || DEFAULT_H;
        canvas.style.height = cssH + 'px';
        canvas.style.width = '100%';
        const cssW = Math.max(120, canvas.clientWidth || (canvas.parentElement && canvas.parentElement.clientWidth) || 300);
        canvas.width = Math.round(cssW * dpr);
        canvas.height = Math.round(cssH * dpr);
        const ctx = canvas.getContext('2d');
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        return { ctx, w: cssW, h: cssH };
    }
    function palette() {
        const cs = getComputedStyle(document.documentElement);
        const v = (name, fb) => (cs.getPropertyValue(name).trim() || fb);
        return {
            line: v('--chart-line', '#2b57e8'),
            line2: v('--chart-line2', '#1c9a6c'),
            fill: v('--chart-fill', 'rgba(43,87,232,.12)'),
            grid: v('--chart-grid', '#eef1f8'),
            ink: v('--chart-ink', '#4b5975'),
            faint: v('--c-ink-faint', '#8a95ab'),
        };
    }
    const FONT = '11px Vazirmatn, Tahoma, sans-serif';
    function drawEmpty(ctx, w, h, msg = 'هنوز داده کافی نیست') {
        const c = palette();
        ctx.clearRect(0, 0, w, h);
        ctx.fillStyle = c.faint;
        ctx.font = '13px Vazirmatn, Tahoma, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(msg, w / 2, h / 2);
    }
    function lineChart(canvas, labels, values, { color, fill = true, format = (v) => Fa.num(v) } = {}) {
        const { ctx, w, h } = setupCanvas(canvas);
        const c = palette();
        color = color || c.line;
        if (!values.length || values.every(v => v == null))
            return drawEmpty(ctx, w, h);
        const pad = { l: 40, r: 10, t: 14, b: 24 };
        const plotW = w - pad.l - pad.r, plotH = h - pad.t - pad.b;
        const nums = values.filter(v => v != null);
        let max = Math.max(...nums) * 1.15 || 1;
        let min = Math.min(0, Math.min(...nums));
        if (max === min)
            max = min + 1;
        ctx.clearRect(0, 0, w, h);
        ctx.strokeStyle = c.grid;
        ctx.lineWidth = 1;
        ctx.fillStyle = c.ink;
        ctx.font = FONT;
        ctx.textAlign = 'right';
        for (let i = 0; i <= 3; i++) {
            const y = pad.t + (plotH / 3) * i;
            ctx.beginPath();
            ctx.moveTo(pad.l, y);
            ctx.lineTo(w - pad.r, y);
            ctx.stroke();
            const val = max - ((max - min) / 3) * i;
            ctx.fillText(format(val), pad.l - 6, y + 4);
        }
        const stepX = plotW / Math.max(1, values.length - 1);
        const xAt = (i) => (values.length === 1 ? pad.l + plotW / 2 : pad.l + stepX * i);
        const toXY = (i, v) => [xAt(i), pad.t + plotH - ((v - min) / (max - min || 1)) * plotH];
        if (fill && nums.length > 1) {
            ctx.beginPath();
            let started = false, lastX = 0;
            values.forEach((v, i) => {
                if (v == null)
                    return;
                const [x, y] = toXY(i, v);
                if (!started) {
                    ctx.moveTo(x, y);
                    started = true;
                }
                else
                    ctx.lineTo(x, y);
                lastX = x;
            });
            const firstIdx = values.findIndex(v => v != null);
            ctx.lineTo(lastX, pad.t + plotH);
            ctx.lineTo(xAt(firstIdx), pad.t + plotH);
            ctx.closePath();
            ctx.fillStyle = c.fill;
            ctx.fill();
        }
        ctx.beginPath();
        ctx.strokeStyle = color;
        ctx.lineWidth = 2.4;
        ctx.lineJoin = 'round';
        let pen = false;
        values.forEach((v, i) => {
            if (v == null) {
                pen = false;
                return;
            }
            const [x, y] = toXY(i, v);
            if (!pen) {
                ctx.moveTo(x, y);
                pen = true;
            }
            else
                ctx.lineTo(x, y);
        });
        ctx.stroke();
        values.forEach((v, i) => {
            if (v == null)
                return;
            const [x, y] = toXY(i, v);
            ctx.beginPath();
            ctx.arc(x, y, 3, 0, Math.PI * 2);
            ctx.fillStyle = color;
            ctx.fill();
        });
        ctx.fillStyle = c.ink;
        ctx.font = FONT;
        ctx.textAlign = 'center';
        const step = Math.ceil(labels.length / 6);
        labels.forEach((lb, i) => {
            if (i % step !== 0)
                return;
            ctx.fillText(lb, xAt(i), h - 6);
        });
    }
    function barChart(canvas, labels, values, { color } = {}) {
        const { ctx, w, h } = setupCanvas(canvas);
        const c = palette();
        color = color || c.line;
        if (!values.length || values.every(v => !v))
            return drawEmpty(ctx, w, h);
        const pad = { l: 40, r: 10, t: 14, b: 24 };
        const plotW = w - pad.l - pad.r, plotH = h - pad.t - pad.b;
        const max = Math.max(...values) * 1.2 || 1;
        ctx.clearRect(0, 0, w, h);
        ctx.strokeStyle = c.grid;
        ctx.lineWidth = 1;
        ctx.fillStyle = c.ink;
        ctx.font = FONT;
        ctx.textAlign = 'right';
        for (let i = 0; i <= 3; i++) {
            const y = pad.t + (plotH / 3) * i;
            ctx.beginPath();
            ctx.moveTo(pad.l, y);
            ctx.lineTo(w - pad.r, y);
            ctx.stroke();
            ctx.fillText(Fa.num(max - (max / 3) * i), pad.l - 6, y + 4);
        }
        const gap = plotW / values.length;
        const barW = Math.min(28, gap * 0.6);
        values.forEach((v, i) => {
            const barH = (v / max) * plotH;
            const x = pad.l + gap * i + (gap - barW) / 2;
            const y = pad.t + plotH - barH;
            ctx.fillStyle = color;
            ctx.beginPath();
            if (ctx.roundRect)
                ctx.roundRect(x, y, barW, barH, 4);
            else
                ctx.rect(x, y, barW, barH);
            ctx.fill();
        });
        ctx.fillStyle = c.ink;
        ctx.font = FONT;
        ctx.textAlign = 'center';
        const step = Math.ceil(labels.length / 6);
        labels.forEach((lb, i) => {
            if (i % step !== 0)
                return;
            ctx.fillText(lb, pad.l + gap * i + gap / 2, h - 6);
        });
    }
    function radarChart(canvas, labels, values01) {
        const { ctx, w, h } = setupCanvas(canvas);
        const c = palette();
        if (!values01.length)
            return drawEmpty(ctx, w, h);
        ctx.clearRect(0, 0, w, h);
        const cx = w / 2, cy = h / 2 + 4, R = Math.min(w, h) / 2 - 28;
        const n = values01.length;
        const angle = (i) => -Math.PI / 2 + (i * 2 * Math.PI) / n;
        ctx.strokeStyle = c.grid;
        ctx.lineWidth = 1;
        for (let ring = 1; ring <= 3; ring++) {
            ctx.beginPath();
            for (let i = 0; i <= n; i++) {
                const a = angle(i % n), r = (R * ring) / 3;
                const x = cx + Math.cos(a) * r, y = cy + Math.sin(a) * r;
                i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
            }
            ctx.stroke();
        }
        ctx.beginPath();
        values01.forEach((v, i) => {
            const a = angle(i), r = R * Math.max(0.05, v);
            const x = cx + Math.cos(a) * r, y = cy + Math.sin(a) * r;
            i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
        });
        ctx.closePath();
        ctx.fillStyle = c.fill;
        ctx.fill();
        ctx.strokeStyle = c.line;
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.fillStyle = c.ink;
        ctx.font = FONT;
        ctx.textAlign = 'center';
        labels.forEach((lb, i) => {
            const a = angle(i);
            const x = cx + Math.cos(a) * (R + 16), y = cy + Math.sin(a) * (R + 16) + 4;
            ctx.fillText(lb, x, y);
        });
    }
    return { lineChart, barChart, radarChart };
})();
window.Charts = Charts;
