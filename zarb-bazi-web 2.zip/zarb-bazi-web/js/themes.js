const Themes = (() => {
    const CATALOG = [
        { id: 'classic', name: 'آبی کلاسیک', price: 0, tier: 'free', bar: '#2b57e8', desc: 'ظاهر اصلی ضرب بازی؛ همیشه رایگان' },
        { id: 'mint', name: 'نعنا', price: 50, tier: 'normal', bar: '#12a37f', desc: 'سبز خنک و آرام برای تمرین طولانی' },
        { id: 'peach', name: 'غروب هلویی', price: 70, tier: 'normal', bar: '#f2684a', desc: 'نارنجی و صورتی گرم یک غروب تابستانی' },
        { id: 'ocean', name: 'دریای آرام', price: 110, tier: 'normal', bar: '#0e8fbf', desc: 'آبی شفاف با حباب‌های آرام', fx: 'bubbles' },
        { id: 'lavender', name: 'یاس', price: 150, tier: 'normal', bar: '#7c5cf0', desc: 'بنفش ملایم با زمینهٔ نقطه‌نقطه' },
        { id: 'midnight', name: 'نیمه‌شب', price: 220, tier: 'normal', bar: '#0b1020', desc: 'تم تیره با ستاره‌های چشمک‌زن', fx: 'stars' },
        { id: 'forest', name: 'جنگل', price: 300, tier: 'normal', bar: '#0c1a14', desc: 'سبز عمیق و زمردی، مناسب شب' },
        { id: 'mocha', name: 'قهوه و خامه', price: 380, tier: 'normal', bar: '#a86a3d', desc: 'کاراملی گرم با زمینهٔ خامه‌ای' },
        { id: 'sakura', name: 'شکوفهٔ بهاری', price: 480, tier: 'normal', bar: '#e8508a', desc: 'صورتی نرم با گلبرگ‌های در حال ریزش', fx: 'petals' },
        { id: 'lime', name: 'گرافیت و لیمو', price: 600, tier: 'normal', bar: '#111214', desc: 'خاکستری تیره با رگه‌های لیموییِ تیز' },
        { id: 'candy', name: 'بستنی', price: 750, tier: 'normal', bar: '#ff5fa2', desc: 'رنگ‌های شاد پاستلی با کانفتی', fx: 'confetti' },
        { id: 'aurora', name: 'شفق قطبی', price: 1500, tier: 'premium', bar: '#050b18', desc: 'روبان‌های نور سبز و بنفش که آسمان شب را می‌رقصانند', fx: 'aurora' },
        { id: 'neon', name: 'نئون شهری', price: 2500, tier: 'premium', bar: '#07040f', desc: 'شهر سایبری شب؛ شبکهٔ نورانی، درخشش نئون و خط‌های اسکن', fx: 'neon' },
        { id: 'galaxy', name: 'کهکشان', price: 4000, tier: 'premium', bar: '#05030f', desc: 'سحابی‌های رنگی، ستاره‌های چشمک‌زن و شهاب‌های گذرا', fx: 'galaxy' },
        { id: 'gold', name: 'طلای سلطنتی', price: 6000, tier: 'premium', bar: '#0b0805', desc: 'سیاه و طلای درخشان با برق‌ِ گذرا و غبار طلایی', fx: 'gold' },
        { id: 'tile', name: 'کاشی فیروزه‌ای', price: 9000, tier: 'premium', bar: '#0d2b5c', desc: 'کاشی‌کاری ستاره‌ای ایرانی با لاجورد، فیروزه و طلا', fx: 'tile' },
        { id: 'royal', name: 'تم پادشاهی', price: 500, tier: 'premium', subOnly: true, bar: '#12060c', desc: 'کاخ شاهنشاهی: ستون‌های تخت‌جمشیدی، مجسمهٔ شاه، مشعل‌های زنده و ارتش گذرا. فقط برای مشترکین 👑', fx: 'royal' },
    ];
    const byId = Object.fromEntries(CATALOG.map(t => [t.id, t]));
    const get = (id) => byId[id] || null;
    function seeded(seed) {
        let a = seed | 0;
        return () => {
            a = (a + 0x6D2B79F5) | 0;
            let t = Math.imul(a ^ (a >>> 15), 1 | a);
            t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
            return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
        };
    }
    const hash = (s) => [...s].reduce((h, c) => (Math.imul(h, 31) + c.charCodeAt(0)) | 0, 7);
    const rr = (r, a, b) => a + (b - a) * r();
    const f1 = (n) => n.toFixed(1);
    function dots(r, n, cls, { size = [1, 2.4], dur = [2.5, 6] } = {}) {
        let out = '';
        for (let i = 0; i < n; i++) {
            const s = rr(r, size[0], size[1]);
            out += `<i class="${cls}" style="left:${f1(rr(r, 0, 100))}%;top:${f1(rr(r, 0, 100))}%;width:${f1(s)}px;height:${f1(s)}px;animation-duration:${f1(rr(r, dur[0], dur[1]))}s;animation-delay:-${f1(rr(r, 0, dur[1]))}s"></i>`;
        }
        return out;
    }
    function risers(r, n, cls, { size = [4, 10], dur = [9, 20], drift = 60 } = {}) {
        let out = '';
        for (let i = 0; i < n; i++) {
            const s = rr(r, size[0], size[1]);
            out += `<i class="${cls}" style="left:${f1(rr(r, 0, 100))}%;width:${f1(s)}px;height:${f1(s)}px;--dx:${Math.round(rr(r, -drift, drift))}px;animation-duration:${f1(rr(r, dur[0], dur[1]))}s;animation-delay:-${f1(rr(r, 0, dur[1]))}s"></i>`;
        }
        return out;
    }
    const FX = {
        stars: (r) => dots(r, 26, 'fx-star'),
        bubbles: (r) => risers(r, 12, 'fx-bubble', { size: [6, 22], dur: [12, 26], drift: 40 }),
        petals: (r) => risers(r, 14, 'fx-petal', { size: [9, 16], dur: [11, 22], drift: 120 }),
        confetti: (r) => dots(r, 22, 'fx-confetti', { size: [5, 10], dur: [4, 9] }),
        aurora: () => '<i class="au au1"></i><i class="au au2"></i><i class="au au3"></i><i class="au-stars"></i>',
        neon: () => '<i class="nx-sun"></i><i class="nx-grid"></i><i class="nx-scan"></i><i class="nx-glow"></i>',
        galaxy: (r) => '<i class="gx-neb gx-n1"></i><i class="gx-neb gx-n2"></i><i class="gx-neb gx-n3"></i>'
            + dots(r, 70, 'fx-star fx-star-lg', { size: [1, 3], dur: [2, 7] })
            + '<i class="gx-shoot s1"></i><i class="gx-shoot s2"></i>',
        gold: (r) => '<i class="gd-sheen"></i>' + risers(r, 22, 'gd-dust', { size: [2, 5], dur: [10, 22], drift: 30 }),
        royal: (r) => '<i class="kg-sky"></i><i class="kg-wing"><svg viewBox="0 0 240 80"><g fill="none" stroke="#ffd76a" stroke-width="3" stroke-linecap="round"><path d="M106 38 Q72 26 18 34"/><path d="M134 38 Q168 26 222 34"/><path d="M106 42 Q64 32 30 44"/><path d="M134 42 Q176 32 210 44"/><path d="M106 46 Q56 38 42 54"/><path d="M134 46 Q184 38 198 54"/><path d="M106 50 Q48 44 54 64"/><path d="M134 50 Q192 44 186 64"/><path d="M106 54 Q40 50 66 74"/><path d="M134 54 Q200 50 174 74"/><path d="M112 58 Q120 78 128 58"/></g><circle cx="120" cy="38" r="15" fill="none" stroke="#ffd76a" stroke-width="4"/><circle cx="120" cy="38" r="7" fill="#ffd76a"/></svg></i><i class="kg-statue"><svg viewBox="0 0 120 220"><defs><linearGradient id="kgs" x1="0" x2="1"><stop offset="0" stop-color="#7a5a12"/><stop offset=".5" stop-color="#ffe08a"/><stop offset="1" stop-color="#8a6a22"/></linearGradient></defs><g fill="url(#kgs)"><path d="M38 34 L44 8 L52 24 L60 4 L68 24 L76 8 L82 34Z"/><ellipse cx="60" cy="52" rx="20" ry="24"/><path d="M42 62 Q60 120 78 62 L78 96 Q60 118 42 96Z"/><path d="M14 130 Q60 96 106 130 L110 170 L10 170Z"/><rect x="26" y="170" width="68" height="14"/><rect x="14" y="184" width="92" height="36"/></g></svg></i>'
            + ['l', 'r'].map(s => `<i class="kg-col kg-${s}"><i class="kg-cap"><svg viewBox="0 0 100 90" preserveAspectRatio="xMidYMin meet"><defs><linearGradient id="kgg" x1="0" x2="1"><stop offset="0" stop-color="#8a6a22"/><stop offset=".5" stop-color="#ffd76a"/><stop offset="1" stop-color="#a47a1c"/></linearGradient></defs><rect x="4" y="2" width="92" height="9" rx="2" fill="url(#kgg)"/><rect x="24" y="20" width="52" height="16" fill="url(#kgg)"/><g fill="url(#kgg)" stroke="#5a3d0a" stroke-width="1.2"><circle cx="22" cy="30" r="15"/><circle cx="78" cy="30" r="15"/></g><g fill="none" stroke="#5a3d0a" stroke-width="1.6"><circle cx="22" cy="30" r="9"/><circle cx="78" cy="30" r="9"/><circle cx="22" cy="30" r="4"/><circle cx="78" cy="30" r="4"/></g><path d="M28 40 Q50 84 72 40Z" fill="url(#kgg)" stroke="#5a3d0a"/><path d="M40 46v14M50 48v18M60 46v14" stroke="#5a3d0a" stroke-width="1.4"/><rect x="26" y="74" width="48" height="5" fill="url(#kgg)"/><rect x="22" y="81" width="56" height="6" fill="url(#kgg)"/></svg></i><i class="kg-shaft"></i><i class="kg-base"><svg viewBox="0 0 100 46" preserveAspectRatio="xMidYMax meet"><rect x="18" y="0" width="64" height="6" fill="url(#kgg)"/><ellipse cx="50" cy="12" rx="38" ry="6" fill="url(#kgg)"/><rect x="8" y="18" width="84" height="12" fill="url(#kgg)"/><rect x="0" y="32" width="100" height="14" fill="url(#kgg)"/></svg></i></i><i class="kg-flame kg-f${s}"></i>`).join('')
            + '<i class="kg-lintel"></i><i class="kg-frieze"></i>' + risers(r, 26, 'gd-dust', { size: [2, 5], dur: [9, 20], drift: 40 }),
        tile: () => '<i class="tl-glow"></i><i class="tl-sweep"></i>',
    };
    const applyListeners = [];
    const onApply = (fn) => applyListeners.push(fn);
    let appliedId = null;
    function apply(id) {
        const t = get(id) || byId.classic;
        const root = document.documentElement;
        root.dataset.theme = t.id;
        root.dataset.tier = t.tier;
        root.dataset.fx = Storage.data.settings.fxOn ? 'on' : 'off';
        const layer = document.querySelector('[data-el="fx"]');
        if (layer && appliedId !== t.id) {
            layer.dataset.fx = t.fx || '';
            layer.innerHTML = t.fx && FX[t.fx] ? FX[t.fx](seeded(hash(t.id))) : '';
        }
        appliedId = t.id;
        const meta = document.querySelector('meta[name="theme-color"]');
        if (meta)
            meta.setAttribute('content', t.bar);
        applyListeners.forEach(fn => { try {
            fn(t);
        }
        catch (e) {
            console.error(e);
        } });
    }
    function applyEquipped() { apply(Storage.data.shop.equipped); }
    function setFxEnabled(on) { document.documentElement.dataset.fx = on ? 'on' : 'off'; }
    let previewId = null;
    function startPreview(id) {
        if (!get(id))
            return;
        previewId = id;
        apply(id);
    }
    function endPreview() {
        if (!previewId)
            return false;
        previewId = null;
        applyEquipped();
        return true;
    }
    const previewing = () => previewId;
    return { CATALOG, get, apply, applyEquipped, setFxEnabled, startPreview, endPreview, previewing, onApply };
})();
window.Themes = Themes;
