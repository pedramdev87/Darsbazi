const Progression = (() => {
    const LEVEL_NAMES = ['', 'مبتدی', 'نوآموز', 'سریع', 'پیشرفته', 'استاد'];
    const LEVEL_THRESHOLDS = [0, 0, 120, 340, 720, 1400, 2600];
    function xpForLevel(level) {
        if (level < LEVEL_THRESHOLDS.length)
            return LEVEL_THRESHOLDS[level];
        return LEVEL_THRESHOLDS[LEVEL_THRESHOLDS.length - 1] + (level - (LEVEL_THRESHOLDS.length - 1)) * 1500;
    }
    function levelName(level) {
        if (level <= 5)
            return LEVEL_NAMES[level] || 'مبتدی';
        return `استاد +${level - 5}`;
    }
    function levelInfo(totalXP) {
        let level = 1;
        while (xpForLevel(level + 1) <= totalXP)
            level++;
        const base = xpForLevel(level);
        const next = xpForLevel(level + 1);
        return {
            level,
            name: levelName(level),
            xpIntoLevel: totalXP - base,
            xpForNext: next - base,
            progressPct: Math.min(100, Math.round(((totalXP - base) / Math.max(1, next - base)) * 100)),
        };
    }
    function computeQuestionXP({ correct, timeMs, targetMs, comboAtThisPoint, scale = 1 }) {
        if (!correct)
            return 0;
        let xp = 5;
        if (timeMs <= targetMs * 0.35)
            xp += 10;
        else if (timeMs <= targetMs * 0.65)
            xp += 5;
        if (comboAtThisPoint > 0 && comboAtThisPoint % 20 === 0)
            xp += 60;
        else if (comboAtThisPoint > 0 && comboAtThisPoint % 10 === 0)
            xp += 25;
        else if (comboAtThisPoint > 0 && comboAtThisPoint % 5 === 0)
            xp += 10;
        return Math.max(1, Math.round(xp * scale));
    }
    function addXP(amount) {
        const p = Storage.data.profile;
        p.totalXP += amount;
        const info = levelInfo(p.totalXP);
        const leveledUp = info.level > p.level;
        p.level = info.level;
        return { leveledUp, info };
    }
    function updateRecords(summary) {
        const r = Storage.data.records;
        const improved = [];
        if (summary.fastestAnswer != null && (r.fastestAnswer == null || summary.fastestAnswer < r.fastestAnswer)) {
            r.fastestAnswer = summary.fastestAnswer;
            improved.push('fastestAnswer');
        }
        if (summary.avgTime != null && summary.total >= 10 && (r.bestAvgTime == null || summary.avgTime < r.bestAvgTime)) {
            r.bestAvgTime = summary.avgTime;
            improved.push('bestAvgTime');
        }
        if (summary.accuracy != null && summary.total >= 10 && (r.bestAccuracy == null || summary.accuracy > r.bestAccuracy)) {
            r.bestAccuracy = summary.accuracy;
            improved.push('bestAccuracy');
        }
        if (summary.bestCombo != null && summary.bestCombo > r.bestStreak) {
            r.bestStreak = summary.bestCombo;
            improved.push('bestStreak');
        }
        if (summary.xpEarned != null && summary.xpEarned > r.bestXPSession) {
            r.bestXPSession = summary.xpEarned;
            improved.push('bestXPSession');
        }
        if (summary.mode === 'speed30' && (r.best30s == null || summary.correct > r.best30s)) {
            r.best30s = summary.correct;
            improved.push('best30s');
        }
        if (summary.mode === 'speed60' && (r.best60s == null || summary.correct > r.best60s)) {
            r.best60s = summary.correct;
            improved.push('best60s');
        }
        if (summary.mode === 'fixed20' && summary.total === 20 && (r.best20q == null || summary.totalTimeMs < r.best20q)) {
            r.best20q = summary.totalTimeMs;
            improved.push('best20q');
        }
        return improved;
    }
    const ACHIEVEMENTS = [
        { id: 'first_practice', icon: '🏅', title: 'اولین تمرین', check: (agg) => agg.totalSessions >= 1 },
        { id: 'q100', icon: '🏅', title: '۱۰۰ سؤال حل‌شده', check: (agg) => agg.totalQuestions >= 100 },
        { id: 'q500', icon: '🏅', title: '۵۰۰ سؤال حل‌شده', check: (agg) => agg.totalQuestions >= 500 },
        { id: 'q2000', icon: '🏅', title: '۲۰۰۰ سؤال حل‌شده', check: (agg) => agg.totalQuestions >= 2000 },
        { id: 'streak10', icon: '🔥', title: '۱۰ پاسخ صحیح پشت‌سرهم', check: (agg) => Storage.data.records.bestStreak >= 10 },
        { id: 'streak20', icon: '🔥', title: '۲۰ پاسخ صحیح پشت‌سرهم', check: (agg) => Storage.data.records.bestStreak >= 20 },
        { id: 'first_record', icon: '🥇', title: 'اولین رکورد شخصی', check: (agg) => agg.hasAnyRecord },
        { id: 'acc95', icon: '🎯', title: 'دقت بالای ۹۵٪', check: (agg) => agg.overallAccuracy >= 0.95 && agg.totalQuestions >= 50 },
        { id: 'level_up', icon: '⭐', title: 'رسیدن به سطح جدید', check: (agg) => Storage.data.profile.level >= 2 },
        { id: 'level5', icon: '👑', title: 'رسیدن به سطح استاد', check: (agg) => Storage.data.profile.level >= 5 },
        { id: 'week_streak', icon: '📅', title: '۷ روز متوالی تمرین', check: (agg) => agg.currentDayStreak >= 7 },
        { id: 'daily_done', icon: '📆', title: 'تکمیل اولین چالش روزانه', check: (agg) => Storage.data.dailyChallenge.completed },
    ];
    function checkAndUnlock(agg) {
        const unlocked = Storage.data.achievements.unlocked;
        const fresh = [];
        ACHIEVEMENTS.forEach(a => {
            if (!unlocked.includes(a.id) && a.check(agg)) {
                unlocked.push(a.id);
                fresh.push(a);
            }
        });
        return fresh;
    }
    function getTodayChallenge() {
        const today = window.AppConst.todayKey();
        const dc = Storage.data.dailyChallenge;
        if (dc.date !== today) {
            const type = Adaptive.currentType();
            const target = Adaptive.TARGET_TIME_MS[type] || 3000;
            Storage.data.dailyChallenge = {
                date: today,
                target: { questionCount: 20, type, timeGoalMs: Math.round(target * 20 * 0.85) },
                completed: false,
                result: null,
            };
        }
        return Storage.data.dailyChallenge;
    }
    function completeDailyChallenge(result) {
        const dc = Storage.data.dailyChallenge;
        dc.completed = true;
        dc.result = result;
    }
    return {
        levelInfo, levelName, computeQuestionXP, addXP, updateRecords,
        ACHIEVEMENTS, checkAndUnlock, getTodayChallenge, completeDailyChallenge,
    };
})();
window.Progression = Progression;
