const Sub = (() => {
    const PRICE = 299000, DAY = 86400000;
    const st = () => Storage.data.sub;
    const active = () => st().until > Date.now();
    function apply() {
        document.documentElement.dataset.sub = active() ? 'on' : 'off';
        document.querySelectorAll('.mode-card[data-sub]').forEach(c => c.classList.toggle('locked', !active()));
    }
    function activateDays(n) {
        const s = st();
        s.until = Math.max(Date.now(), s.until) + n * DAY;
        Storage.save();
        apply();
    }
    function statusText() {
        if (!active())
            return 'اشتراک فعال نیست';
        const h = Math.ceil((st().until - Date.now()) / 3600000);
        return h >= 48 ? `اشتراک فعال است — ${Fa.num(Math.ceil(h / 24))} روز مانده` : `اشتراک فعال است — ${Fa.num(h)} ساعت مانده`;
    }
    const PERKS = ['چک‌نویس (نوشتن با انگشت + پاک‌کن) در همهٔ حالت‌ها', 'بدون تبلیغات', 'حالت معادله (پایهٔ هفتم تا نهم)', 'حالت جمع‌های صحیح', 'حالت اول یا مرکب (تشخیص اعداد اول)', 'تم پادشاهی (فقط با اشتراک قابل خرید)', 'سکهٔ بیشتر در هر تمرین', 'XP سه برابر'];
    return { PRICE, active, apply, activateDays, statusText, PERKS };
})();
window.Sub = Sub;
