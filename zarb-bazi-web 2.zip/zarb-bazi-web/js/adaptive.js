const Adaptive = (() => {
    const { TYPES, MULTIPLIERS } = window.AppConst;
    const TARGET_TIME_MS = { '1x1': 2500, '2x1': 4200, '2x2': 6500, '3x1': 5200, '3x2': 8500, '3x3': 12000 };
    const WINDOW = 15;
    const FACT_RECENT = 6;
    function typeStat(type) { return Storage.data.typeStats[type]; }
    function rollingAccuracy(type) {
        const s = typeStat(type);
        if (!s.recentAcc.length)
            return null;
        return s.recentAcc.reduce((a, b) => a + b, 0) / s.recentAcc.length;
    }
    function rollingAvgTime(type) {
        const s = typeStat(type);
        if (!s.recentTime.length)
            return null;
        return s.recentTime.reduce((a, b) => a + b, 0) / s.recentTime.length;
    }
    function currentType() {
        const manual = Storage.data.settings.manualLevel;
        if (manual && manual !== 'auto')
            return TYPES[Number(manual) - 1] || '1x1';
        return Storage.data.adaptive.currentType;
    }
    function evaluateProgression() {
        if (Storage.data.settings.manualLevel !== 'auto')
            return null;
        const type = Storage.data.adaptive.currentType;
        const idx = TYPES.indexOf(type);
        const acc = rollingAccuracy(type);
        const avgT = rollingAvgTime(type);
        const s = typeStat(type);
        if (s.recentAcc.length < WINDOW)
            return null;
        const target = TARGET_TIME_MS[type];
        if (acc >= 0.9 && avgT <= target * 1.15 && idx < TYPES.length - 1) {
            Storage.data.adaptive.currentType = TYPES[idx + 1];
            typeStat(TYPES[idx + 1]).recentAcc = [];
            typeStat(TYPES[idx + 1]).recentTime = [];
            return { direction: 'up', newType: TYPES[idx + 1] };
        }
        if (acc < 0.62 && idx > 0) {
            Storage.data.adaptive.currentType = TYPES[idx - 1];
            typeStat(TYPES[idx - 1]).recentAcc = [];
            typeStat(TYPES[idx - 1]).recentTime = [];
            return { direction: 'down', newType: TYPES[idx - 1] };
        }
        return null;
    }
    function weakestMultipliers(limit = 3) {
        const stats = Storage.data.multiplierStats;
        const scored = MULTIPLIERS
            .map(m => {
            const st = stats[m];
            if (st.attempts < 3)
                return null;
            const acc = st.correct / st.attempts;
            const avgT = st.totalTime / st.attempts;
            const score = (1 - acc) * 2000 + avgT;
            return { m, acc, avgT, score, attempts: st.attempts };
        })
            .filter(Boolean)
            .sort((a, b) => b.score - a.score);
        return scored.slice(0, limit);
    }
    function createPicker(type, plan) {
        const facts = (plan && plan.focusFacts) || [];
        const mults = (plan && plan.focusMults) || [];
        const hasFocus = (type === '1x1' && facts.length > 0) || (QuestionGenerator.HAS_SINGLE_DIGIT[type] && mults.length > 0);
        const poolSize = type === '1x1' && facts.length ? facts.length : mults.length;
        const ratio = !hasFocus ? 0 : poolSize >= 3 ? 0.7 : poolSize === 2 ? 0.6 : 0.4;
        let n = 0, served = 0, queue = [], lastKey = null, multTurn = 0;
        return function next() {
            n++;
            const recentKeys = Storage.data.recentQuestions.slice(-6).map(q => q.key);
            const opts = { recentKeys };
            const focusSlot = hasFocus && served < ratio * n - 1e-9;
            if (focusSlot) {
                served++;
                if (type === '1x1' && facts.length) {
                    if (!queue.length)
                        queue = QuestionGenerator.shuffle(facts.length > 1 ? [...facts, facts[0]] : facts);
                    let key = queue.shift();
                    if (key === lastKey && queue.length) {
                        queue.push(key);
                        key = queue.shift();
                    }
                    lastKey = key;
                    opts.forceFact = key;
                }
                else {
                    opts.biasMultiplier = mults[multTurn++ % mults.length];
                }
            }
            return QuestionGenerator.generate(type, opts);
        };
    }
    function emptyFact() {
        return { attempts: 0, correct: 0, wrong: 0, totalTime: 0, recent: [], wrongAns: {}, last: 0 };
    }
    function recordAnswer(question, correct, timeMs, opts = {}) {
        const { given = null, mc = false } = opts;
        const type = question.type;
        if (!mc && Storage.data.typeStats[type]) {
            const ts = typeStat(type);
            ts.attempts++;
            if (correct)
                ts.correct++;
            ts.totalTime += timeMs;
            ts.recentAcc.push(correct ? 1 : 0);
            ts.recentTime.push(timeMs);
            if (ts.recentAcc.length > WINDOW)
                ts.recentAcc.shift();
            if (ts.recentTime.length > WINDOW)
                ts.recentTime.shift();
        }
        [question.a, question.b].forEach(n => {
            if (n >= 2 && n <= 9) {
                const ms = Storage.data.multiplierStats[String(n)];
                ms.attempts++;
                if (correct)
                    ms.correct++;
                ms.totalTime += timeMs;
            }
        });
        if (type === '1x1') {
            const fs = Storage.data.factStats[question.key] || emptyFact();
            fs.attempts++;
            if (correct)
                fs.correct++;
            else
                fs.wrong++;
            fs.totalTime += timeMs;
            fs.recent.push({ c: correct ? 1 : 0, t: Math.round(timeMs), m: mc ? 1 : 0 });
            if (fs.recent.length > FACT_RECENT)
                fs.recent.shift();
            if (!correct && given != null && Number.isFinite(given)) {
                const k = String(given);
                fs.wrongAns[k] = (fs.wrongAns[k] || 0) + 1;
                const keys = Object.keys(fs.wrongAns);
                if (keys.length > 5) {
                    keys.sort((x, y) => fs.wrongAns[y] - fs.wrongAns[x]);
                    keys.slice(5).forEach(x => delete fs.wrongAns[x]);
                }
            }
            fs.last = Date.now();
            Storage.data.factStats[question.key] = fs;
        }
        return mc ? null : evaluateProgression();
    }
    function adjustMentalTime(correct, timeMs) {
        const s = Storage.data.settings;
        const steps = [500, 1000, 1500, 2000, 2500, 3000];
        let idx = steps.indexOf(s.mentalDisplayTime);
        if (idx === -1)
            idx = steps.reduce((bi, v, i) => Math.abs(v - s.mentalDisplayTime) < Math.abs(steps[bi] - s.mentalDisplayTime) ? i : bi, 0);
        if (correct && timeMs < 4000 && idx > 0)
            idx--;
        else if (!correct && idx < steps.length - 1)
            idx++;
        s.mentalDisplayTime = steps[idx];
    }
    return {
        TARGET_TIME_MS, FACT_RECENT, currentType, evaluateProgression,
        weakestMultipliers, createPicker, recordAnswer, adjustMentalTime,
    };
})();
window.Adaptive = Adaptive;
