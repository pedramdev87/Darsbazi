const Pad = (() => {
    let panel, cv, ctx, tool = 'pen', pts = null, dpr = 1;
    const $ = (s) => document.querySelector(s);
    const open = () => !panel.classList.contains('hidden');
    function fit() {
        const r = cv.getBoundingClientRect();
        dpr = Math.min(window.devicePixelRatio || 1, 3);
        const w = Math.round(r.width * dpr), h = Math.round(r.height * dpr);
        if (cv.width !== w || cv.height !== h) {
            cv.width = w;
            cv.height = h;
        }
    }
    function pos(e) { const r = cv.getBoundingClientRect(); return [(e.clientX - r.left) * dpr, (e.clientY - r.top) * dpr]; }
    function seg(a, b) {
        ctx.globalCompositeOperation = tool === 'eraser' ? 'destination-out' : 'source-over';
        ctx.strokeStyle = getComputedStyle(document.documentElement).getPropertyValue('--c-ink').trim() || '#101a33';
        ctx.lineWidth = (tool === 'eraser' ? 26 : 3.2) * dpr;
        ctx.lineCap = ctx.lineJoin = 'round';
        ctx.beginPath();
        ctx.moveTo(a[0], a[1]);
        ctx.lineTo(b[0], b[1]);
        ctx.stroke();
    }
    function setTool(t) { tool = t; panel.querySelectorAll('[data-pad-tool]').forEach(b => b.classList.toggle('on', b.dataset.padTool === t)); }
    function clear() { if (ctx)
        ctx.clearRect(0, 0, cv.width, cv.height); }
    function close() { if (panel)
        panel.classList.add('hidden'); }
    function toggle() {
        if (!Sub.active()) {
            toast('چک‌نویس مخصوص مشترکین است 🔒 (بعد از تمرین از فروشگاه اشتراک بگیر)');
            return;
        }
        panel.classList.toggle('hidden');
        if (open()) {
            fit();
            setTool('pen');
        }
    }
    function bind() {
        panel = $('[data-el="pad"]');
        cv = $('[data-el="padCanvas"]');
        ctx = cv.getContext('2d');
        $('[data-action="toggle-pad"]').addEventListener('click', toggle);
        panel.querySelectorAll('[data-pad-tool]').forEach(b => b.addEventListener('click', () => setTool(b.dataset.padTool)));
        $('[data-pad="clear"]').addEventListener('click', clear);
        cv.addEventListener('pointerdown', (e) => { e.preventDefault(); cv.setPointerCapture(e.pointerId); pts = pos(e); seg(pts, [pts[0] + 0.01, pts[1]]); });
        cv.addEventListener('pointermove', (e) => { if (!pts)
            return; const p = pos(e); seg(pts, p); pts = p; });
        ['pointerup', 'pointercancel'].forEach(t => cv.addEventListener(t, () => { pts = null; }));
        window.addEventListener('resize', () => { if (open())
            fit(); });
    }
    return { bind, clear, close, onQuestion: () => { if (ctx)
            clear(); } };
})();
window.Pad = Pad;
