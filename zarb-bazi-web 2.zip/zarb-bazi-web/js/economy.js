const Economy = (() => {
    const CFG = {
        dropChance: { '1x1': 0.05, '2x1': 0.07, '3x1': 0.08, '2x2': 0.09, '3x2': 0.11, '3x3': 0.13 },
        modeFactor: { choice4: 0.5, mental: 1.3 },
        fastAnswerFactor: 1.4,
        fastAnswerRatio: 0.65,
        comboEvery: 10, comboCoins: 1,
        perfectSession: { minQuestions: 10, minAccuracy: 0.9, coins: 1 },
        dailyChallengeCoins: 3,
        achievementCoins: 5,
        subCoinFactor: 2,
        levelUpCoins: 10,
    };
    const CODES = {
        'start': { coins: 100, subDays: 1, once: true },
    };
    const listeners = [];
    const onChange = (fn) => listeners.push(fn);
    const notify = () => listeners.forEach(fn => { try {
        fn();
    }
    catch (e) {
        console.error(e);
    } });
    const profile = () => Storage.data.profile;
    const shop = () => Storage.data.shop;
    const balance = () => profile().coins;
    function add(n) {
        n = Math.floor(Number(n) || 0);
        if (n <= 0)
            return 0;
        profile().coins += n;
        profile().coinsEarned += n;
        notify();
        return n;
    }
    function spend(n) {
        n = Math.floor(Number(n) || 0);
        if (n < 0 || balance() < n)
            return false;
        profile().coins -= n;
        notify();
        return true;
    }
    function rollDrop({ type, mode, timeMs, targetMs }, rng = Math.random) {
        let p = CFG.dropChance[type] || 0.05;
        p *= CFG.modeFactor[mode] || 1;
        if (window.Sub && Sub.active())
            p *= CFG.subCoinFactor;
        if (targetMs && timeMs != null && timeMs <= targetMs * CFG.fastAnswerRatio)
            p *= CFG.fastAnswerFactor;
        return rng() < p ? 1 : 0;
    }
    function comboReward(combo) {
        return combo > 0 && combo % CFG.comboEvery === 0 ? CFG.comboCoins : 0;
    }
    function sessionBonus(summary) {
        const c = CFG.perfectSession;
        return summary.total >= c.minQuestions && summary.accuracy >= c.minAccuracy ? c.coins : 0;
    }
    function ownsTheme(id) { return shop().owned.includes(id); }
    function equippedTheme() { return shop().equipped; }
    function buyTheme(id) {
        const t = Themes.get(id);
        if (!t)
            return { ok: false, reason: 'unknown' };
        if (ownsTheme(id))
            return { ok: false, reason: 'owned' };
        if (t.subOnly && !Sub.active())
            return { ok: false, reason: 'sub' };
        if (balance() < t.price)
            return { ok: false, reason: 'poor', missing: t.price - balance() };
        spend(t.price);
        shop().owned.push(id);
        shop().equipped = id;
        Storage.save();
        return { ok: true, theme: t };
    }
    function equipTheme(id) {
        if (!Themes.get(id) || !ownsTheme(id))
            return false;
        shop().equipped = id;
        Storage.save();
        return true;
    }
    function redeem(raw) {
        const code = Fa.toEn(raw).trim().toLowerCase().replace(/\s+/g, '');
        if (!code)
            return { ok: false, reason: 'empty' };
        const def = CODES[code];
        if (!def)
            return { ok: false, reason: 'invalid' };
        const used = shop().redeemed;
        if (def.once && used.includes(code))
            return { ok: false, reason: 'used' };
        if (!used.includes(code))
            used.push(code);
        if (def.coins)
            add(def.coins);
        if (def.subDays)
            Sub.activateDays(def.subDays);
        Storage.save();
        return { ok: true, coins: def.coins || 0, subDays: def.subDays || 0 };
    }
    function buyCoach(id) {
        const m = Mascot.get(id);
        if (!m)
            return { ok: false, reason: 'unknown' };
        if (shop().coachOwned.includes(id))
            return { ok: false, reason: 'owned' };
        if (balance() < m.price)
            return { ok: false, reason: 'poor', missing: m.price - balance() };
        spend(m.price);
        shop().coachOwned.push(id);
        shop().coachEquipped = id;
        Storage.save();
        return { ok: true, coach: m };
    }
    function equipCoach(id) {
        if (!Mascot.get(id) || !shop().coachOwned.includes(id))
            return false;
        shop().coachEquipped = id;
        Storage.save();
        return true;
    }
    async function redeemAsync(raw) {
        const t = String(raw || '').trim();
        return /^ZB1\./i.test(t) ? Device.redeemSigned('ZB1.' + t.slice(4)) : redeem(raw);
    }
    function sanitize() {
        const s = shop();
        const okc = (id) => typeof id === 'string' && !!Mascot.get(id);
        s.coachOwned = Array.from(new Set(['classic', ...(Array.isArray(s.coachOwned) ? s.coachOwned : []).filter(okc)]));
        if (!okc(s.coachEquipped) || !s.coachOwned.includes(s.coachEquipped))
            s.coachEquipped = 'classic';
        const valid = (id) => typeof id === 'string' && !!Themes.get(id);
        s.owned = Array.from(new Set(['classic', ...(Array.isArray(s.owned) ? s.owned : []).filter(valid)]));
        if (!valid(s.equipped) || !s.owned.includes(s.equipped))
            s.equipped = 'classic';
        s.redeemed = Array.from(new Set((Array.isArray(s.redeemed) ? s.redeemed : []).filter(x => typeof x === 'string')));
    }
    return {
        CFG, CODES, onChange, balance, add, spend, rollDrop, comboReward, sessionBonus,
        ownsTheme, equippedTheme, buyTheme, equipTheme, buyCoach, equipCoach, redeem, redeemAsync, sanitize,
    };
})();
window.Economy = Economy;
