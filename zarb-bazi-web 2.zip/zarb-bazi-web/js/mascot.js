const Mascot = (() => {
    const SKINS = [
        { id: 'classic', name: 'توپولی', price: 0, body: '#4f7dff', ear: '#3a62e0', desc: 'مربی دوست‌داشتنی و همیشگی؛ ساده و مهربان' },
        { id: 'astro', name: 'فضانورد', price: 400, body: '#e8eefc', ear: '#c3cfee', desc: 'با کلاه فضانوردی، آمادهٔ پرواز به سمت رکوردهای جدید' },
        { id: 'ninja', name: 'نینجا', price: 800, body: '#30354f', ear: '#222639', desc: 'تیز و بی‌صدا؛ با هدبند قرمز نینجایی' },
        { id: 'pirate', name: 'دزد دریایی', price: 1300, body: '#f0a45a', ear: '#d98a3e', desc: 'با چشم‌بند و دستمال سر؛ دنبال گنج جواب‌های درست' },
        { id: 'prof', name: 'پروفسور', price: 3500, special: true, body: '#f3d9ae', ear: '#dcbf8f', desc: 'باهوش‌تر از بقیه: تحلیل‌هایش فوق‌العاده دقیق است (آمار هر ضرب، الگوی خطا، راهبرد حل) و با لحن رسمی و دانشگاهی با تو حرف می‌زند' },
    ];
    const byId = Object.fromEntries(SKINS.map(s => [s.id, s]));
    const get = (id) => byId[id] || null;
    const current = () => get(Storage.data.shop.coachEquipped) || byId.classic;
    const isProf = () => current().id === 'prof';
    const ACC = {
        classic: '',
        astro: '<circle cx="60" cy="66" r="53" fill="#9ed8ff" fill-opacity=".22" stroke="#fff" stroke-width="4"/><path d="M30 44 Q44 28 66 30" stroke="#fff" stroke-opacity=".7" stroke-width="4" fill="none" stroke-linecap="round"/><rect x="57" y="6" width="6" height="14" rx="3" fill="#cfd8ee"/><circle cx="60" cy="6" r="5" fill="#ff5a5f"/>',
        ninja: '<path d="M16 50 Q60 36 104 50 L104 62 Q60 48 16 62Z" fill="#e63946"/><path d="M104 54 L118 46 L116 58 L120 68 L104 60Z" fill="#c1121f"/><rect x="50" y="46" width="20" height="10" rx="2" fill="#b0b6cf"/>',
        pirate: '<path d="M16 54 Q22 18 60 16 Q98 18 104 54 Q60 40 16 54Z" fill="#d62828"/><circle cx="40" cy="34" r="3" fill="#fff"/><circle cx="62" cy="28" r="3" fill="#fff"/><circle cx="82" cy="36" r="3" fill="#fff"/><path d="M104 50 L116 56 L106 62Z" fill="#d62828"/><circle cx="44" cy="62" r="13" fill="#1a1a1a"/><path d="M31 56 L18 46" stroke="#1a1a1a" stroke-width="3"/>',
        prof: '<path d="M26 30 L60 14 L94 30 L60 44Z" fill="#23262f"/><rect x="44" y="40" width="32" height="10" rx="4" fill="#23262f"/><path d="M94 30 L98 50" stroke="#e0a82e" stroke-width="3"/><circle cx="98" cy="52" r="4" fill="#e0a82e"/><circle cx="44" cy="62" r="14" fill="none" stroke="#5a3d0a" stroke-width="3"/><circle cx="76" cy="62" r="14" fill="none" stroke="#5a3d0a" stroke-width="3"/><path d="M58 62 L62 62" stroke="#5a3d0a" stroke-width="3"/><path d="M44 83 Q52 76 60 82 Q68 76 76 83 Q68 90 60 85 Q52 90 44 83Z" fill="#6b4a1f"/><path d="M50 108 L60 100 L70 108 L60 114Z" fill="#c1121f"/>',
    };
    function svg(id, size) {
        const k = get(id) || byId.classic;
        const px = size ? ` width="${size}" height="${size}"` : '';
        return `<svg class="mascot" viewBox="0 0 120 120"${px} aria-hidden="true">
<circle cx="26" cy="30" r="15" fill="${k.ear}"/><circle cx="94" cy="30" r="15" fill="${k.ear}"/>
<circle cx="26" cy="30" r="8" fill="#ffb4c0" fill-opacity=".8"/><circle cx="94" cy="30" r="8" fill="#ffb4c0" fill-opacity=".8"/>
<g class="m-body"><circle cx="60" cy="66" r="46" fill="${k.body}"/>
<circle cx="34" cy="80" r="7" fill="#ff8aa0" fill-opacity=".35"/><circle cx="86" cy="80" r="7" fill="#ff8aa0" fill-opacity=".35"/>
<g class="m-eye"><ellipse cx="44" cy="62" rx="10" ry="11" fill="#fff"/><circle class="m-pupil" cx="46" cy="64" r="5.2" fill="#1b2340"/><circle cx="48" cy="61" r="1.8" fill="#fff"/></g>
<g class="m-eye"><ellipse cx="76" cy="62" rx="10" ry="11" fill="#fff"/><circle class="m-pupil" cx="78" cy="64" r="5.2" fill="#1b2340"/><circle cx="80" cy="61" r="1.8" fill="#fff"/></g>
<path d="M50 86 Q60 95 70 86" stroke="#1b2340" stroke-width="3.4" fill="none" stroke-linecap="round"/>
${ACC[k.id] || ''}</g></svg>`;
    }
    function mount() {
        const k = current();
        document.querySelectorAll('[data-mascot]').forEach((el) => { el.innerHTML = svg(k.id); el.dataset.skin = k.id; });
        document.querySelectorAll('[data-coach-title]').forEach((el) => { el.textContent = isProf() ? 'کارنامهٔ تخصصی' : (el.dataset.coachTitle || 'تحلیل مربی'); });
    }
    return { SKINS, get, current, isProf, svg, mount };
})();
window.Mascot = Mascot;
