const Advanced = (() => {
    Adaptive.TARGET_TIME_MS.eq = 30000;
    Adaptive.TARGET_TIME_MS.int = 14000;
    Adaptive.TARGET_TIME_MS.prime = 5000;
    const R = (a, b) => Math.floor(Math.random() * (b - a + 1)) + a;
    const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
    const nz = (a, b) => { let v = 0; while (!v)
        v = R(a, b); return v; };
    const LTR = (s) => '\u2066' + s + '\u2069';
    const MINUS = '−';
    const sg = (n) => (n < 0 ? MINUS + Fa.toFa(-n) : Fa.toFa(n));
    const lit = (n) => (n < 0 ? `(${sg(n)})` : sg(n));
    const signed = (n) => `${n < 0 ? MINUS : '+'} ${Fa.toFa(Math.abs(n))}`;
    const coef = (a) => (a === 1 ? '' : a === -1 ? MINUS : sg(a));
    const lin = (a, b, v = 'x') => `${coef(a)}${v}${b ? ' ' + signed(b) : ''}`;
    const finish = (lines, prompt, answer, type) => {
        const display = lines.map(LTR).join('\n') + (prompt ? '\n' + prompt : '');
        return { a: 0, b: 0, type, answer, key: display, display };
    };
    const unseen = (k) => !Storage.data.recentQuestions.some(q => q.key === k);
    function intExpr(grade) {
        const leaf = (n) => ({ s: lit(n), v: n, c: false });
        const join = (l, op, r) => {
            const w = (x) => (x.c ? `(${x.s})` : x.s);
            const v = op === '+' ? l.v + r.v : op === MINUS ? l.v - r.v : op === '×' ? l.v * r.v : l.v / r.v;
            return { s: `${w(l)} ${op} ${w(r)}`, v, c: true };
        };
        let nodes = [leaf(nz(-40, 40)), leaf(nz(-40, 40)), leaf(nz(-30, 30))];
        if (grade >= 8) {
            const d = nz(-9, 9), k = nz(-9, 9);
            nodes.push(Math.random() < 0.5 ? join(leaf(d * k), '÷', leaf(d)) : join(leaf(nz(-9, 9)), '×', leaf(nz(-9, 9))));
            if (Math.random() < 0.6)
                nodes.push(leaf(nz(-25, 25)));
            nodes.sort(() => Math.random() - 0.5);
        }
        else
            nodes.push(leaf(nz(-40, 40)));
        while (nodes.length > 1) {
            const i = R(0, nodes.length - 2);
            nodes.splice(i, 2, join(nodes[i], Math.random() < 0.5 ? '+' : MINUS, nodes[i + 1]));
        }
        return nodes[0];
    }
    function integers(grade) {
        for (let t = 0; t < 60; t++) {
            const e = intExpr(grade);
            if (Math.abs(e.v) <= 300 && e.v !== 0 && unseen(LTR(e.s)))
                return finish([e.s], '', e.v, 'int');
        }
        const e = intExpr(grade);
        return finish([e.s], '', e.v, 'int');
    }
    function eq7() {
        const x = nz(-12, 12), p = R(2, 9), q = nz(-9, 9), r = nz(-12, 12);
        let s = nz(-6, 8);
        if (s === p)
            s = p + 1;
        const t = (p - s) * x + p * q + r;
        return [`${Fa.toFa(p)}(x ${signed(q)}) ${signed(r)} = ${lin(s, t)}`, 'x = ؟', x];
    }
    function eq8() {
        const x = nz(-12, 12);
        if (Math.random() < 0.5) {
            const m = R(2, 5);
            let n = R(2, 6);
            if (n === m)
                n++;
            let a = (((m - (x % m)) % m) + m) % m + m * R(0, 2);
            if (!a)
                a = m;
            let b = (((x % n) + n) % n) + n * R(0, 2);
            if (!b)
                b = n;
            const c = (x + a) / m - (x - b) / n;
            return [`(x + ${Fa.toFa(a)})/${Fa.toFa(m)} ${MINUS} (x ${MINUS} ${Fa.toFa(b)})/${Fa.toFa(n)} = ${sg(c)}`, 'x = ؟', x];
        }
        const p = R(2, 9), s = R(2, 9), q = nz(-9, 9), u = nz(-9, 9);
        const w = p * (x + q) - s * (x + u);
        return [`${Fa.toFa(p)}(x ${signed(q)}) ${MINUS} ${Fa.toFa(s)}(x ${signed(u)}) = ${sg(w)}`, 'x = ؟', x];
    }
    function eq9() {
        if (Math.random() < 0.5) {
            let r1 = nz(-9, 9), r2 = nz(-9, 9);
            if (r1 === r2)
                r2 = r1 > 0 ? -r1 : -r1 + 1 || 2;
            const a = R(1, 3), b = -a * (r1 + r2), c = a * r1 * r2;
            return [`${a === 1 ? '' : Fa.toFa(a)}x² ${b ? signed(b).replace(/(\d+)$/, '$1') + 'x ' : ''}${c ? signed(c) + ' ' : ''}= ۰`.replace(/\s+/g, ' '), 'ریشهٔ بزرگ‌تر = ؟', Math.max(r1, r2)];
        }
        for (;;) {
            const x = nz(-9, 9), y = nz(-9, 9), p = nz(-5, 5), q = nz(-5, 5), u = nz(-5, 5), v = nz(-5, 5);
            if (p * v - q * u === 0)
                continue;
            const L = (a, b) => `${coef(a)}x ${b < 0 ? MINUS : '+'} ${Math.abs(b) === 1 ? '' : Fa.toFa(Math.abs(b))}y`;
            return [`${L(p, q)} = ${sg(p * x + q * y)}\n${L(u, v)} = ${sg(u * x + v * y)}`.split('\n'), 'x = ؟', x];
        }
    }
    function equations(grade) {
        const gen = grade >= 9 ? eq9 : grade === 8 ? eq8 : eq7;
        for (let t = 0; t < 60; t++) {
            let [lines, prompt, ans] = gen();
            if (!Array.isArray(lines))
                lines = [lines];
            const key = lines.map(LTR).join('\n') + '\n' + prompt;
            if (unseen(key))
                return finish(lines, prompt, ans, 'eq');
        }
        let [lines, prompt, ans] = gen();
        return finish(Array.isArray(lines) ? lines : [lines], prompt, ans, 'eq');
    }
    const isPrime = (n) => { if (n < 2)
        return false; for (let i = 2; i * i <= n; i++)
        if (n % i === 0)
            return false; return true; };
    const factorsOf = (n) => { const f = []; for (let p = 2; p * p <= n; p++)
        while (n % p === 0) {
            f.push(p);
            n /= p;
        } if (n > 1)
        f.push(n); return f; };
    const poolCache = {};
    function primePools(lo, hi) {
        const k = lo + ':' + hi;
        if (!poolCache[k]) {
            const primes = [], tricky = [], composite = [];
            for (let n = lo; n <= hi; n++) {
                if (isPrime(n))
                    primes.push(n);
                else {
                    composite.push(n);
                    const f = factorsOf(n);
                    if (f.length === 2 && f[0] >= 7)
                        tricky.push(n);
                }
            }
            poolCache[k] = { primes, tricky, composite };
        }
        return poolCache[k];
    }
    function primes() {
        const wide = String(Storage.data.settings.primeRange) === '1000';
        const lo = wide ? 10 : 2, hi = wide ? 1000 : 100;
        const pool = primePools(lo, hi);
        const recent = Storage.data.recentQuestions.slice(-20).map(q => q.key);
        let n = 0;
        for (let t = 0; t < 40; t++) {
            const wantPrime = Math.random() < 0.5;
            n = wantPrime ? pick(pool.primes) : (Math.random() < 0.45 && pool.tricky.length ? pick(pool.tricky) : pick(pool.composite));
            if (!recent.includes('p' + n))
                break;
        }
        const yes = isPrime(n);
        return { a: 0, b: 0, type: 'prime', prime: true, answer: yes ? 1 : 0, key: 'p' + n, display: Fa.toFa(n),
            explain: yes ? `${Fa.toFa(n)} اول است` : LTR(`${Fa.toFa(n)} = ${factorsOf(n).map(x => Fa.toFa(x)).join(' × ')}`) };
    }
    function next(kind) {
        if (kind === 'prime')
            return primes();
        const g = Number(Storage.data.settings.grade) || 7;
        return kind === 'eq' ? equations(g) : integers(g);
    }
    function bindSign() {
        const inp = document.querySelector('[data-el="answerInput"]'), btn = document.querySelector('[data-el="signBtn"]');
        if (!btn)
            return;
        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            inp.value = inp.value.startsWith('-') ? inp.value.slice(1) : '-' + inp.value;
            inp.focus();
        });
    }
    return { next, bindSign };
})();
window.Advanced = Advanced;
