const CACHE = 'zarb-bazi-web-v2';
const FONTS = 'zarb-bazi-fonts-v1';
const ASSETS = ["./", "index.html", "app.html", "manifest.json", "css/style.css", "css/themes.css", "css/landing.css", "js/landing.js", "js/storage.js", "js/fa.js", "js/audio.js", "js/questionGenerator.js", "js/adaptive.js", "js/progression.js", "js/stats.js", "js/charts.js", "js/coach.js", "js/themes.js", "js/mascot.js", "js/economy.js", "js/device.js", "js/sub.js", "js/pad.js", "js/advanced.js", "js/dialog.js", "js/ui.js", "js/shop.js", "js/app.js", "icons/icon-192.png", "icons/icon-512.png", "icons/icon-maskable-512.png", "icons/apple-touch-icon.png"];
self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE && k !== FONTS).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
function fontRequest(e) {
  e.respondWith(caches.open(FONTS).then((c) => c.match(e.request).then((hit) => {
    const net = fetch(e.request).then((r) => { if (r && (r.ok || r.type === 'opaque')) c.put(e.request, r.clone()); return r; }).catch(() => hit);
    return hit || net;
  })));
}
self.addEventListener('fetch', (e) => {
  if (e.request.method !== 'GET') return;
  const url = new URL(e.request.url);
  if (url.hostname === 'fonts.googleapis.com' || url.hostname === 'fonts.gstatic.com') { fontRequest(e); return; }
  if (url.origin !== location.origin) return;
  e.respondWith(
    fetch(e.request).then((r) => {
      if (r && r.ok) { const copy = r.clone(); caches.open(CACHE).then((c) => c.put(e.request, copy)); }
      return r;
    }).catch(() => caches.match(e.request, { ignoreSearch: true }).then((m) => m || (e.request.mode === 'navigate' ? caches.match('app.html') : Response.error())))
  );
});
